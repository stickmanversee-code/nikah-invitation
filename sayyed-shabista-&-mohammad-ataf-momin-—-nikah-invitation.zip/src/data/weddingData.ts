export interface GalleryItem {
  id: string;
  src: string;
  title: string;
  caption: string;
  category: 'attire' | 'details';
  aspect: 'portrait' | 'landscape' | 'wide';
}

export const WEDDING_DETAILS = {
  bride: 'Sayyed Shabista',
  groom: 'Mohammad Ataf Momin',
  coupleShort: 'Shabista & Ataf',
  dateDisplay: 'Wednesday, 23 December 2026',
  dateShort: '23 Dec 2026',
  isoTarget: '2026-12-23T18:15:00+05:30',
  nikahTime: 'After Namaz-e-Maghrib',
  nikahDetail: 'Sacred Nikah Khutbah, Ijab-o-Qubool & Duas',
  dinnerTime: '7:00 PM to 11:00 PM',
  dinnerDetail: 'Grand celebratory dinner hosted with family warmth',
  venueName: 'Noor Baug Hall',
  venueLandmark: 'Behind Shimla Park, Kausa',
  venueCity: 'Mumbra, Thane - 400612',
  venueFull: 'Noor Baug Hall, Behind Shimla Park, Kausa, Mumbra, Thane - 400612',
  googleMapsUrl:
    'https://www.google.com/maps/dir/?api=1&destination=Noor+Baug+Hall+Behind+Shimla+Park+Kausa+Mumbra+Thane+400612',
  googleMapsSearchUrl:
    'https://www.google.com/maps/search/?api=1&query=Noor+Baug+Hall+Behind+Shimla+Park+Kausa+Mumbra+Thane+400612',
};

export const GALLERY_ITEMS: GalleryItem[] = [
  {
    id: 'decor-sanctuary',
    src: '/src/assets/images/white_gold_decor_1795539447817.jpg',
    title: 'The Nikah Sanctuary',
    caption: 'White florals, golden lanterns & warm candlelight.',
    category: 'details',
    aspect: 'wide',
  },
  {
    id: 'bride-silhouette',
    src: '/src/assets/images/bride_modest_back_1795538610824.jpg',
    title: 'Sayyed Shabista',
    caption: 'With grace, serenity & blessings.',
    category: 'attire',
    aspect: 'portrait',
  },
  {
    id: 'groom-silhouette',
    src: '/src/assets/images/groom_sherwani_clean_1795538634977.jpg',
    title: 'Mohammad Ataf Momin',
    caption: 'With dignity, gratitude & prayers.',
    category: 'attire',
    aspect: 'portrait',
  },
  {
    id: 'mehndi-jewellery',
    src: '/src/assets/images/mehndi_hands_jewellery_1795538611719.jpg',
    title: 'Mehndi & White Roses',
    caption: 'Tradition, joy & warm blessings.',
    category: 'details',
    aspect: 'landscape',
  },
  {
    id: 'rings-lanterns',
    src: '/src/assets/images/white_gold_rings_1795539448138.jpg',
    title: 'Sacred Tokens & Lanterns',
    caption: 'Wednesday, 23 December 2026.',
    category: 'details',
    aspect: 'landscape',
  },
];

export function buildWhatsAppShareUrl(siteUrl: string): string {
  const message = [
    '*Bismillah-ir-Rahman-ir-Rahim*',
    '',
    'With the blessings of Allah (SWT), you are cordially invited to grace the auspicious Nikah ceremony of:',
    '',
    `*${WEDDING_DETAILS.bride}*`,
    '&',
    `*${WEDDING_DETAILS.groom}*`,
    '',
    `Date: ${WEDDING_DETAILS.dateDisplay}`,
    `Nikah: ${WEDDING_DETAILS.nikahTime}`,
    `Dinner: ${WEDDING_DETAILS.dinnerTime}`,
    `Venue: ${WEDDING_DETAILS.venueFull}`,
    '',
    'View the invitation, directions & RSVP here:',
    siteUrl,
  ].join('\n');

  return `https://wa.me/?text=${encodeURIComponent(message)}`;
}

export function buildWhatsAppRsvpUrl(params: {
  guestName: string;
  attending: 'yes' | 'no';
  guestCount: number;
  ceremonyPreference: 'both' | 'nikah' | 'dinner';
  confirmationCode: string;
  duaMessage?: string;
}): string {
  const preferenceLabel =
    params.ceremonyPreference === 'both'
      ? 'Nikah Ceremony & Dinner'
      : params.ceremonyPreference === 'nikah'
        ? 'Nikah Ceremony'
        : 'Wedding Dinner';

  const lines = [
    'Assalamu Alaikum,',
    '',
    `RSVP Confirmation for the Nikah of *${WEDDING_DETAILS.bride}* & *${WEDDING_DETAILS.groom}*`,
    `Reference: ${params.confirmationCode}`,
    `Name: ${params.guestName}`,
    params.attending === 'yes'
      ? `Status: Attending (${params.guestCount} ${params.guestCount === 1 ? 'Guest' : 'Guests'} · ${preferenceLabel})`
      : 'Status: Unable to attend in person (Sending prayers & blessings)',
  ];

  if (params.duaMessage && params.duaMessage.trim().length > 0) {
    lines.push(`Dua / Blessing: "${params.duaMessage.trim()}"`);
  }

  return `https://wa.me/?text=${encodeURIComponent(lines.join('\n'))}`;
}

export function downloadCalendarIcs(): void {
  const icsContent = [
    'BEGIN:VCALENDAR',
    'VERSION:2.0',
    'PRODID:-//Shabista & Ataf Nikah Invitation//EN',
    'CALSCALE:GREGORIAN',
    'METHOD:PUBLISH',
    'BEGIN:VEVENT',
    'UID:nikah-shabista-ataf-20261223@noorbaughall',
    'DTSTAMP:20261124T000000Z',
    'DTSTART:20261223T123000Z',
    'DTEND:20261223T173000Z',
    'SUMMARY:Nikah Ceremony — Sayyed Shabista & Mohammad Ataf Momin',
    `LOCATION:${WEDDING_DETAILS.venueFull}`,
    'DESCRIPTION:Bismillah-ir-Rahman-ir-Rahim. Nikah Ceremony after Namaz-e-Maghrib followed by Dinner from 7:00 PM to 11:00 PM at Noor Baug Hall, Behind Shimla Park, Kausa, Mumbra, Thane - 400612.',
    'STATUS:CONFIRMED',
    'END:VEVENT',
    'END:VCALENDAR',
  ].join('\r\n');

  const blob = new Blob([icsContent], { type: 'text/calendar;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = 'Nikah-Shabista-Ataf-23Dec2026.ics';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}
