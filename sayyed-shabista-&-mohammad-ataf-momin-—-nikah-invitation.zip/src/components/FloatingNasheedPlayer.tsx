import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Music, Pause, Play, Volume2, VolumeX } from 'lucide-react';

const NASHEED_VIDEO_ID = 'ivrumxRUz_Y';

interface YTPlayer {
  playVideo: () => void;
  pauseVideo: () => void;
  seekTo: (seconds: number, allowSeekAhead: boolean) => void;
  mute: () => void;
  unMute: () => void;
  isMuted: () => boolean;
  setVolume: (volume: number) => void;
  destroy: () => void;
}

interface YTNamespace {
  Player: new (
    elementId: string | HTMLElement,
    options: {
      height?: string | number;
      width?: string | number;
      videoId: string;
      playerVars?: Record<string, string | number>;
      events?: {
        onReady?: (event: { target: YTPlayer }) => void;
        onStateChange?: (event: { data: number; target: YTPlayer }) => void;
        onError?: () => void;
      };
    },
  ) => YTPlayer;
  PlayerState?: {
    ENDED: number;
    PLAYING: number;
    PAUSED: number;
    BUFFERING: number;
    CUED: number;
  };
}

declare global {
  interface Window {
    YT?: YTNamespace;
    onYouTubeIframeAPIReady?: () => void;
  }
}

export function useYouTubeNasheed() {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const playerRef = useRef<YTPlayer | null>(null);
  const playerReadyRef = useRef(false);
  const pendingPlayRef = useRef(false);

  const [hasActivated, setHasActivated] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [hasError, setHasError] = useState(false);

  useEffect(() => {
    let mounted = true;

    const initPlayer = () => {
      if (!mounted || !containerRef.current || !window.YT?.Player || playerRef.current) {
        return;
      }

      playerRef.current = new window.YT.Player(containerRef.current, {
        width: '200',
        height: '120',
        videoId: NASHEED_VIDEO_ID,
        playerVars: {
          autoplay: 0,
          controls: 0,
          disablekb: 1,
          fs: 0,
          iv_load_policy: 3,
          modestbranding: 1,
          playsinline: 1,
          rel: 0,
          loop: 1,
          playlist: NASHEED_VIDEO_ID,
          start: 0,
          enablejsapi: 1,
          origin: window.location.origin,
        },
        events: {
          onReady: (event) => {
            if (!mounted) return;
            playerReadyRef.current = true;
            if (pendingPlayRef.current) {
              pendingPlayRef.current = false;
              try {
                event.target.unMute();
                event.target.setVolume(100);
                event.target.seekTo(0, true);
                event.target.playVideo();
                setIsMuted(false);
              } catch {
                // Playback will remain ready for manual play button if blocked
              }
            }
          },
          onStateChange: (event) => {
            if (!mounted) return;
            const state = event.data;
            if (state === 1) {
              setIsPlaying(true);
              setHasError(false);
            } else if (state === 2 || state === -1 || state === 5) {
              setIsPlaying(false);
            } else if (state === 0) {
              event.target.seekTo(0, true);
              event.target.playVideo();
            }
          },
          onError: () => {
            if (!mounted) return;
            setHasError(true);
            setIsPlaying(false);
          },
        },
      });
    };

    if (window.YT?.Player) {
      initPlayer();
    } else {
      const existingScript = document.querySelector<HTMLScriptElement>(
        'script[src="https://www.youtube.com/iframe_api"]',
      );
      const prevCallback = window.onYouTubeIframeAPIReady;
      window.onYouTubeIframeAPIReady = () => {
        if (typeof prevCallback === 'function') prevCallback();
        initPlayer();
      };

      if (!existingScript) {
        const script = document.createElement('script');
        script.src = 'https://www.youtube.com/iframe_api';
        script.async = true;
        document.head.appendChild(script);
      }
    }

    return () => {
      mounted = false;
      if (playerRef.current) {
        try {
          playerRef.current.destroy();
        } catch {
          // Ignore destroy errors on unmount
        }
        playerRef.current = null;
        playerReadyRef.current = false;
      }
    };
  }, []);

  const hasStartedOnceRef = useRef(false);

  const startFromBeginning = useCallback(() => {
    setHasActivated(true);
    setHasError(false);

    const player = playerRef.current;
    if (player && playerReadyRef.current) {
      try {
        player.unMute();
        player.setVolume(100);
        if (hasStartedOnceRef.current) {
          player.seekTo(0, true);
        }
        player.playVideo();
        hasStartedOnceRef.current = true;
        setIsMuted(false);
      } catch {
        pendingPlayRef.current = true;
      }
    } else {
      pendingPlayRef.current = true;
    }
  }, []);

  const togglePlay = useCallback(() => {
    const player = playerRef.current;
    if (!player || !playerReadyRef.current) {
      pendingPlayRef.current = true;
      return;
    }

    if (isPlaying) {
      player.pauseVideo();
    } else {
      if (!isMuted) {
        player.unMute();
        player.setVolume(100);
      }
      player.playVideo();
    }
  }, [isPlaying, isMuted]);

  const toggleMute = useCallback(() => {
    const player = playerRef.current;
    if (!player || !playerReadyRef.current) return;

    if (isMuted) {
      player.unMute();
      player.setVolume(100);
      setIsMuted(false);
    } else {
      player.mute();
      setIsMuted(true);
    }
  }, [isMuted]);

  return {
    containerRef,
    hasActivated,
    isPlaying,
    isMuted,
    hasError,
    startFromBeginning,
    togglePlay,
    toggleMute,
  };
}

interface FloatingNasheedPlayerProps {
  visible: boolean;
  isPlaying: boolean;
  isMuted: boolean;
  hasError: boolean;
  onTogglePlay: () => void;
  onToggleMute: () => void;
}

export function FloatingNasheedPlayer({
  visible,
  isPlaying,
  isMuted,
  hasError,
  onTogglePlay,
  onToggleMute,
}: FloatingNasheedPlayerProps) {
  if (!visible) return null;

  const statusText = hasError
    ? 'Tap Play'
    : isMuted
      ? 'Muted'
      : isPlaying
        ? 'Playing'
        : 'Paused';

  return (
    <aside
      aria-label="Wedding Nasheed Audio Controls"
      className="fixed bottom-4 right-4 sm:bottom-6 sm:right-6 z-40"
    >
      <div className="flex items-center gap-2 rounded-xl border border-[#C59B43]/80 bg-[#FFFFFF]/95 backdrop-blur-md pl-3.5 pr-2 py-2 shadow-[0_14px_36px_rgba(140,99,24,0.22)]">
        <div className="flex items-center gap-2.5 pr-1">
          <span
            className="flex h-8 w-8 items-center justify-center rounded-lg bg-[#FAF6EE] border border-[#C59B43]/50 text-[#9A6F20]"
            aria-hidden="true"
          >
            <Music className="w-4 h-4" />
          </span>
          <div className="leading-tight pr-1">
            <p className="font-serif text-sm font-semibold text-[#2B2113] whitespace-nowrap">
              Nikah Nasheed
            </p>
            <p className="text-[11px] font-medium text-[#8C6318] whitespace-nowrap">
              {statusText}
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={onTogglePlay}
          aria-label={isPlaying ? 'Pause nasheed' : 'Play nasheed'}
          className="inline-flex h-10 w-10 sm:h-11 sm:w-11 items-center justify-center rounded-lg bg-[#9A6F20] text-[#FFFFFF] hover:bg-[#8C6318] active:scale-95 transition-all cursor-pointer shrink-0"
        >
          {isPlaying ? (
            <Pause className="w-4 h-4" />
          ) : (
            <Play className="w-4 h-4 translate-x-[1px]" />
          )}
        </button>

        <button
          type="button"
          onClick={onToggleMute}
          aria-label={isMuted ? 'Unmute nasheed' : 'Mute nasheed'}
          className="inline-flex h-10 w-10 sm:h-11 sm:w-11 items-center justify-center rounded-lg border border-[#C59B43]/60 bg-[#FAF6EE] text-[#8C6318] hover:bg-[#F4EDE0] active:scale-95 transition-all cursor-pointer shrink-0"
        >
          {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
        </button>
      </div>
    </aside>
  );
}
