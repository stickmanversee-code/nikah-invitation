import React, { useState } from 'react';
import { Clock, Copy, Check, ExternalLink, MapPin, Utensils } from 'lucide-react';
import { WEDDING_DETAILS } from '../data/weddingData';
import { GoldGeometricDivider } from './IslamicOrnaments';

export function ScheduleAndVenue() {
  const [copiedAddress, setCopiedAddress] = useState(false);

  const handleCopyAddress = async () => {
    try {
      await navigator.clipboard.writeText(WEDDING_DETAILS.venueFull);
      setCopiedAddress(true);
      window.setTimeout(() => setCopiedAddress(false), 2600);
    } catch {
      setCopiedAddress(false);
    }
  };

  return (
    <>
      {/* Schedule Section: Nikah Ceremony & Dinner */}
      <section id="schedule" className="bg-[#FFFFFF] py-16 sm:py-24">
        <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto">
            <p className="text-xs sm:text-sm tracking-[0.26em] uppercase text-[#8C6318] font-medium">
              Programme of the Evening
            </p>
            <h2 className="mt-3 font-serif text-3xl sm:text-4xl md:text-5xl font-medium text-[#2B2113]">
              Ceremony &amp; Hospitality
            </h2>
            <p className="mt-3 text-sm sm:text-base text-[#6B5B45]">
              {WEDDING_DETAILS.dateDisplay} · {WEDDING_DETAILS.venueName}, Mumbra
            </p>
          </div>

          <div className="mt-12 grid grid-cols-1 md:grid-cols-2 gap-8 items-stretch">
            {/* 01. Nikah Ceremony */}
            <article className="flex flex-col justify-between rounded-lg border border-[#C59B43]/50 bg-[#FAF6EE] p-8 sm:p-10">
              <div>
                <div className="flex items-center justify-between gap-4 border-b border-[#C59B43]/30 pb-5">
                  <span className="font-serif text-lg text-[#8C6318]">01.</span>
                  <Clock className="w-5 h-5 text-[#B38734]" aria-hidden="true" />
                </div>
                <h3 className="mt-6 font-serif text-3xl font-medium text-[#2B2113]">
                  Nikah Ceremony
                </h3>
                <p className="mt-2 text-base font-medium text-[#8C6318]">
                  {WEDDING_DETAILS.nikahTime}
                </p>
                <p className="mt-4 text-sm sm:text-base leading-relaxed text-[#6B5B45]">
                  The sacred Nikah Khutbah, Ijab-o-Qubool, and collective Dua for the newlyweds
                  will commence immediately following Namaz-e-Maghrib. We kindly request your
                  punctual presence to join us in prayer.
                </p>
              </div>
              <div className="mt-8 pt-5 border-t border-[#C59B43]/25 text-xs tracking-[0.16em] uppercase text-[#6B5B45]">
                Wednesday, 23 December 2026 · Sacred Union
              </div>
            </article>

            {/* 02. Wedding Dinner */}
            <article className="flex flex-col justify-between rounded-lg border border-[#C59B43]/50 bg-[#FAF6EE] p-8 sm:p-10">
              <div>
                <div className="flex items-center justify-between gap-4 border-b border-[#C59B43]/30 pb-5">
                  <span className="font-serif text-lg text-[#8C6318]">02.</span>
                  <Utensils className="w-5 h-5 text-[#B38734]" aria-hidden="true" />
                </div>
                <h3 className="mt-6 font-serif text-3xl font-medium text-[#2B2113]">
                  Wedding Dinner
                </h3>
                <p className="mt-2 text-base font-medium text-[#8C6318] tabular-nums">
                  {WEDDING_DETAILS.dinnerTime}
                </p>
                <p className="mt-4 text-sm sm:text-base leading-relaxed text-[#6B5B45]">
                  Following the Nikah solemnisation, we invite you and your family to share in an
                  evening of celebratory dinner, traditional hospitality, and warm fellowship at{' '}
                  {WEDDING_DETAILS.venueName}.
                </p>
              </div>
              <div className="mt-8 pt-5 border-t border-[#C59B43]/25 text-xs tracking-[0.16em] uppercase text-[#6B5B45]">
                7:00 PM – 11:00 PM · Noor Baug Hall
              </div>
            </article>
          </div>
        </div>
      </section>

      {/* Venue Address & Google Maps Directions */}
      <section
        id="venue"
        className="border-t border-b border-[#C59B43]/30 bg-[#FAF6EE] py-16 sm:py-24"
      >
        <div className="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8">
          <div className="rounded-lg border border-[#C59B43]/55 bg-[#FFFFFF] p-8 sm:p-12 md:p-14 text-center shadow-[0_12px_36px_rgba(140,99,24,0.06)]">
            <p className="text-xs sm:text-sm tracking-[0.26em] uppercase text-[#8C6318] font-medium">
              Venue &amp; Directions
            </p>
            <h2 className="mt-3 font-serif text-3xl sm:text-4xl md:text-5xl font-medium text-[#2B2113]">
              {WEDDING_DETAILS.venueName}
            </h2>

            <GoldGeometricDivider className="my-6 max-w-xs mx-auto" />

            {/* Clickable Venue Address for Google Maps */}
            <a
              href={WEDDING_DETAILS.googleMapsUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="group inline-block rounded-lg px-5 py-4 transition-colors hover:bg-[#FAF6EE] focus:outline-none focus-visible:ring-2 focus-visible:ring-[#8C6318]"
              aria-label="Open Noor Baug Hall address in Google Maps"
            >
              <div className="flex items-center justify-center gap-2 text-[#B38734]">
                <MapPin className="w-5 h-5 shrink-0" />
                <span className="text-xs tracking-[0.18em] uppercase font-medium">
                  Tap Address for Google Maps
                </span>
              </div>
              <p className="mt-2 font-serif text-xl sm:text-2xl text-[#2B2113] group-hover:text-[#8C6318] transition-colors">
                {WEDDING_DETAILS.venueName}, {WEDDING_DETAILS.venueLandmark}
              </p>
              <p className="mt-1 text-base sm:text-lg text-[#6B5B45]">
                {WEDDING_DETAILS.venueCity}
              </p>
            </a>

            <div className="mt-8 flex flex-wrap items-center justify-center gap-4">
              <a
                href={WEDDING_DETAILS.googleMapsUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center gap-2 min-h-[44px] px-7 py-3 rounded-md bg-[#9A6F20] text-[#FFFFFF] text-sm font-medium hover:bg-[#8C6318] transition-colors whitespace-nowrap"
              >
                <span>Open Google Maps Directions</span>
                <ExternalLink className="w-4 h-4 text-[#F5E9CC]" />
              </a>

              <button
                type="button"
                onClick={handleCopyAddress}
                className="inline-flex items-center justify-center gap-2 min-h-[44px] px-6 py-3 rounded-md border border-[#C59B43]/75 text-[#8C6318] text-sm font-medium hover:bg-[#FAF6EE] transition-colors cursor-pointer whitespace-nowrap"
              >
                {copiedAddress ? (
                  <>
                    <Check className="w-4 h-4 text-[#8C6318]" />
                    <span>Address Copied</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-4 h-4 text-[#B38734]" />
                    <span>Copy Address</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
