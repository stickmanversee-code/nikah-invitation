import React, { useEffect, useState } from 'react';
import { CalendarPlus } from 'lucide-react';
import { WEDDING_DETAILS, downloadCalendarIcs } from '../data/weddingData';

interface TimeRemaining {
  days: number;
  hours: number;
  minutes: number;
  seconds: number;
  completed: boolean;
}

function calculateRemaining(): TimeRemaining {
  const targetMs = new Date(WEDDING_DETAILS.isoTarget).getTime();
  const nowMs = Date.now();
  const diff = targetMs - nowMs;

  if (diff <= 0) {
    return { days: 0, hours: 0, minutes: 0, seconds: 0, completed: true };
  }

  const days = Math.floor(diff / (1000 * 60 * 60 * 24));
  const hours = Math.floor((diff / (1000 * 60 * 60)) % 24);
  const minutes = Math.floor((diff / (1000 * 60)) % 60);
  const seconds = Math.floor((diff / 1000) % 60);

  return { days, hours, minutes, seconds, completed: false };
}

export function CountdownSection() {
  const [remaining, setRemaining] = useState<TimeRemaining>(() => calculateRemaining());
  const [savedCalendar, setSavedCalendar] = useState(false);

  useEffect(() => {
    const interval = window.setInterval(() => {
      setRemaining(calculateRemaining());
    }, 1000);
    return () => window.clearInterval(interval);
  }, []);

  const handleDownloadCalendar = () => {
    downloadCalendarIcs();
    setSavedCalendar(true);
    window.setTimeout(() => setSavedCalendar(false), 3000);
  };

  const units = [
    { label: 'Days', value: remaining.days },
    { label: 'Hours', value: remaining.hours },
    { label: 'Minutes', value: remaining.minutes },
    { label: 'Seconds', value: remaining.seconds },
  ];

  return (
    <section
      aria-label="Live Wedding Countdown"
      className="bg-gradient-to-b from-[#FAF6EE] via-[#F4EDE0] to-[#FAF6EE] text-[#2B2113] py-14 sm:py-20 border-b border-[#C59B43]/35"
    >
      <div className="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8 text-center">
        <p className="text-xs sm:text-sm tracking-[0.26em] uppercase text-[#8C6318] font-medium">
          Counting Down to the Blessed Day
        </p>
        <h2 className="mt-3 font-serif text-3xl sm:text-4xl font-medium text-[#2B2113]">
          {remaining.completed
            ? 'Alhamdulillah — The Blessed Day Has Arrived'
            : WEDDING_DETAILS.dateDisplay}
        </h2>

        {!remaining.completed ? (
          <div className="mt-10 grid grid-cols-2 sm:grid-cols-4 gap-4 sm:gap-6 max-w-3xl mx-auto">
            {units.map((unit) => (
              <div
                key={unit.label}
                className="rounded-lg border border-[#C59B43]/60 bg-[#FFFFFF] px-4 py-6 sm:py-7 shadow-[0_6px_20px_rgba(140,99,24,0.06)]"
              >
                <div className="font-serif text-4xl sm:text-5xl font-semibold text-[#8C6318] tabular-nums tracking-tight">
                  {String(unit.value).padStart(2, '0')}
                </div>
                <div className="mt-2 text-xs tracking-[0.22em] uppercase text-[#6B5B45]">
                  {unit.label}
                </div>
              </div>
            ))}
          </div>
        ) : (
          <p className="mt-4 font-serif italic text-xl text-[#8C6318]">
            Barakallahu Lakuma wa Baraka Alaikuma wa Jama’a Bainakuma fi Khair
          </p>
        )}

        <div className="mt-9 flex flex-col sm:flex-row items-center justify-center gap-4">
          <button
            type="button"
            onClick={handleDownloadCalendar}
            className="inline-flex items-center justify-center gap-2.5 min-h-[44px] px-6 py-2.5 rounded-md bg-[#9A6F20] text-[#FFFFFF] text-sm font-medium hover:bg-[#8C6318] transition-colors cursor-pointer whitespace-nowrap"
          >
            <CalendarPlus className="w-4 h-4 text-[#F5E9CC]" />
            <span>{savedCalendar ? 'Calendar Invite Downloaded' : 'Add Date to Calendar'}</span>
          </button>
          <span className="text-xs sm:text-sm text-[#6B5B45]">
            Nikah after Namaz-e-Maghrib · Dinner 7:00 PM to 11:00 PM
          </span>
        </div>
      </div>
    </section>
  );
}
