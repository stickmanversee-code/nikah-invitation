import React, { useCallback, useEffect, useState } from 'react';
import { CheckCircle2, Search, Send, MessageCircle, Users } from 'lucide-react';
import { buildWhatsAppRsvpUrl } from '../data/weddingData';

interface PublicBlessing {
  id: string;
  guestName: string;
  duaMessage: string;
  attending: 'yes' | 'no';
  updatedAt: string;
}

interface RsvpSummary {
  totalResponses: number;
  confirmedFamilies: number;
  totalAttendingGuests: number;
  publicBlessings: PublicBlessing[];
}

interface ConfirmationRecord {
  confirmationCode: string;
  guestName: string;
  attending: 'yes' | 'no';
  guestCount: number;
  ceremonyPreference: 'both' | 'nikah' | 'dinner';
  duaMessage: string;
  shareDuaPublicly: boolean;
  updatedAt: string;
}

export function RsvpSection() {
  const [guestName, setGuestName] = useState('');
  const [phone, setPhone] = useState('');
  const [attending, setAttending] = useState<'yes' | 'no'>('yes');
  const [guestCount, setGuestCount] = useState<number>(2);
  const [ceremonyPreference, setCeremonyPreference] = useState<'both' | 'nikah' | 'dinner'>('both');
  const [duaMessage, setDuaMessage] = useState('');
  const [shareDuaPublicly, setShareDuaPublicly] = useState(true);

  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [confirmation, setConfirmation] = useState<ConfirmationRecord | null>(null);
  const [wasUpdate, setWasUpdate] = useState(false);

  const [summary, setSummary] = useState<RsvpSummary | null>(null);
  const [summaryLoading, setSummaryLoading] = useState(true);

  const [lookupPhone, setLookupPhone] = useState('');
  const [lookupBusy, setLookupBusy] = useState(false);
  const [lookupError, setLookupError] = useState<string | null>(null);
  const [showLookup, setShowLookup] = useState(false);

  const loadSummary = useCallback(async () => {
    try {
      const res = await fetch('/api/rsvp/summary');
      if (res.ok) {
        const data = (await res.json()) as RsvpSummary;
        setSummary(data);
      }
    } catch {
      // Keep UI resilient if summary fetch fails temporarily
    } finally {
      setSummaryLoading(false);
    }
  }, []);

  useEffect(() => {
    loadSummary();
  }, [loadSummary]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitError(null);
    setSubmitting(true);

    try {
      const res = await fetch('/api/rsvp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          guestName,
          phone,
          attending,
          guestCount: attending === 'yes' ? guestCount : 0,
          ceremonyPreference,
          duaMessage,
          shareDuaPublicly,
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        setSubmitError(data.error || 'Could not record your RSVP. Please check your details.');
        return;
      }

      setConfirmation(data.confirmation as ConfirmationRecord);
      setWasUpdate(Boolean(data.isUpdate));
      await loadSummary();
    } catch {
      setSubmitError('Network error while saving your RSVP. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleLookup = async (e: React.FormEvent) => {
    e.preventDefault();
    setLookupError(null);
    setLookupBusy(true);

    try {
      const res = await fetch(`/api/rsvp/lookup?phone=${encodeURIComponent(lookupPhone)}`);
      const data = await res.json();
      if (!res.ok) {
        setLookupError(data.error || 'No RSVP found for this phone number.');
        return;
      }

      const found = data as ConfirmationRecord;
      setConfirmation(found);
      setWasUpdate(false);
      setGuestName(found.guestName);
      setPhone(lookupPhone);
      setAttending(found.attending);
      setGuestCount(found.guestCount || 1);
      setCeremonyPreference(found.ceremonyPreference);
      setDuaMessage(found.duaMessage);
      setShareDuaPublicly(found.shareDuaPublicly);
      setShowLookup(false);
    } catch {
      setLookupError('Unable to check RSVP right now.');
    } finally {
      setLookupBusy(false);
    }
  };

  const handleEditConfirmed = () => {
    setConfirmation(null);
  };

  return (
    <section
      id="rsvp"
      className="border-t border-[#C59B43]/30 bg-[#FAF6EE] py-16 sm:py-24"
    >
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-start">
          {/* Left Column: Real RSVP Form or Verified Confirmation Pass */}
          <div className="lg:col-span-7 rounded-lg border border-[#C59B43]/50 bg-[#FFFFFF] p-6 sm:p-10 shadow-[0_12px_32px_rgba(140,99,24,0.05)]">
            <div className="flex flex-wrap items-center justify-between gap-4 border-b border-[#C59B43]/25 pb-6">
              <div>
                <p className="text-xs tracking-[0.24em] uppercase text-[#8C6318] font-medium">
                  Kindly Respond
                </p>
                <h2 className="mt-1.5 font-serif text-3xl sm:text-4xl font-medium text-[#2B2113]">
                  RSVP Confirmation
                </h2>
              </div>

              <button
                type="button"
                onClick={() => {
                  setShowLookup((prev) => !prev);
                  setLookupError(null);
                }}
                className="inline-flex items-center gap-1.5 min-h-[40px] px-3.5 py-2 text-xs font-medium text-[#8C6318] border border-[#C59B43]/55 rounded-md hover:bg-[#FAF6EE] transition-colors cursor-pointer whitespace-nowrap"
              >
                <Search className="w-3.5 h-3.5 text-[#B38734]" />
                <span>{showLookup ? 'Back to Form' : 'Check Existing RSVP'}</span>
              </button>
            </div>

            {showLookup ? (
              <form onSubmit={handleLookup} className="mt-6 space-y-5">
                <p className="text-sm text-[#6B5B45]">
                  Enter the contact or WhatsApp number you used earlier to retrieve or update your
                  recorded RSVP.
                </p>
                <div>
                  <label
                    htmlFor="lookup-phone"
                    className="block text-xs font-medium tracking-wide uppercase text-[#2B2113] mb-2"
                  >
                    Phone / WhatsApp Number
                  </label>
                  <input
                    id="lookup-phone"
                    type="tel"
                    required
                    value={lookupPhone}
                    onChange={(e) => setLookupPhone(e.target.value)}
                    placeholder="e.g. +91 98200 00000"
                    className="w-full min-h-[44px] rounded-md border border-[#C59B43]/50 bg-[#FFFFFF] px-4 py-2.5 text-sm text-[#2B2113] focus:border-[#9A6F20] focus:outline-none focus:ring-1 focus:ring-[#9A6F20]"
                  />
                </div>
                {lookupError && (
                  <p role="alert" className="text-sm text-[#8C4A18]">
                    {lookupError}
                  </p>
                )}
                <button
                  type="submit"
                  disabled={lookupBusy}
                  className="inline-flex items-center justify-center gap-2 min-h-[44px] px-6 py-2.5 rounded-md bg-[#9A6F20] text-[#FFFFFF] text-sm font-medium hover:bg-[#8C6318] transition-colors cursor-pointer disabled:opacity-60"
                >
                  <Search className="w-4 h-4 text-[#F5E9CC]" />
                  <span>{lookupBusy ? 'Checking...' : 'Find My RSVP'}</span>
                </button>
              </form>
            ) : confirmation ? (
              <div className="mt-8 space-y-6">
                <div className="rounded-lg border border-[#C59B43]/60 bg-[#FAF6EE] text-[#2B2113] p-6 sm:p-8">
                  <div className="flex items-start gap-3">
                    <CheckCircle2 className="w-6 h-6 text-[#9A6F20] shrink-0 mt-0.5" />
                    <div>
                      <p className="text-xs tracking-[0.2em] uppercase text-[#8C6318] font-medium">
                        {wasUpdate ? 'RSVP Updated & Saved' : 'Verified RSVP Recorded'}
                      </p>
                      <h3 className="mt-1 font-serif text-2xl sm:text-3xl font-medium text-[#2B2113]">
                        JazakAllahu Khairan, {confirmation.guestName}
                      </h3>
                    </div>
                  </div>

                  <dl className="mt-6 grid grid-cols-1 sm:grid-cols-2 gap-4 border-t border-[#C59B43]/30 pt-5 text-sm">
                    <div>
                      <dt className="text-xs uppercase tracking-wider text-[#6B5B45]">
                        Reference Code
                      </dt>
                      <dd className="mt-1 font-semibold tabular-nums text-[#8C6318]">
                        {confirmation.confirmationCode}
                      </dd>
                    </div>
                    <div>
                      <dt className="text-xs uppercase tracking-wider text-[#6B5B45]">
                        Attendance Status
                      </dt>
                      <dd className="mt-1 font-medium text-[#2B2113]">
                        {confirmation.attending === 'yes'
                          ? `Attending · ${confirmation.guestCount} ${
                              confirmation.guestCount === 1 ? 'Guest' : 'Guests'
                            }`
                          : 'Unable to attend in person'}
                      </dd>
                    </div>
                    {confirmation.attending === 'yes' && (
                      <div>
                        <dt className="text-xs uppercase tracking-wider text-[#6B5B45]">
                          Ceremony &amp; Dinner
                        </dt>
                        <dd className="mt-1 font-medium text-[#2B2113]">
                          {confirmation.ceremonyPreference === 'both'
                            ? 'Nikah Ceremony & Wedding Dinner'
                            : confirmation.ceremonyPreference === 'nikah'
                              ? 'Nikah Ceremony Only'
                              : 'Wedding Dinner Only'}
                        </dd>
                      </div>
                    )}
                    <div>
                      <dt className="text-xs uppercase tracking-wider text-[#6B5B45]">
                        Recorded On
                      </dt>
                      <dd className="mt-1 text-[#2B2113] tabular-nums">
                        {new Date(confirmation.updatedAt).toLocaleDateString('en-IN', {
                          day: 'numeric',
                          month: 'short',
                          year: 'numeric',
                        })}
                      </dd>
                    </div>
                  </dl>
                </div>

                <div className="flex flex-wrap items-center gap-3">
                  <a
                    href={buildWhatsAppRsvpUrl(confirmation)}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center justify-center gap-2 min-h-[44px] px-6 py-3 rounded-md bg-[#9A6F20] text-[#FFFFFF] text-sm font-medium hover:bg-[#8C6318] transition-colors whitespace-nowrap"
                  >
                    <MessageCircle className="w-4 h-4 text-[#F5E9CC]" />
                    <span>Send Confirmation via WhatsApp</span>
                  </a>

                  <button
                    type="button"
                    onClick={handleEditConfirmed}
                    className="inline-flex items-center justify-center min-h-[44px] px-5 py-3 rounded-md border border-[#C59B43]/75 text-[#8C6318] text-sm font-medium hover:bg-[#FAF6EE] transition-colors cursor-pointer whitespace-nowrap"
                  >
                    Modify Response
                  </button>
                </div>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="mt-6 space-y-5">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                  <div>
                    <label
                      htmlFor="rsvp-name"
                      className="block text-xs font-medium tracking-wide uppercase text-[#2B2113] mb-2"
                    >
                      Full Name
                    </label>
                    <input
                      id="rsvp-name"
                      type="text"
                      required
                      minLength={2}
                      maxLength={80}
                      value={guestName}
                      onChange={(e) => setGuestName(e.target.value)}
                      placeholder="Your full name or family name"
                      className="w-full min-h-[44px] rounded-md border border-[#C59B43]/50 bg-[#FFFFFF] px-4 py-2.5 text-sm text-[#2B2113] focus:border-[#9A6F20] focus:outline-none focus:ring-1 focus:ring-[#9A6F20]"
                    />
                  </div>

                  <div>
                    <label
                      htmlFor="rsvp-phone"
                      className="block text-xs font-medium tracking-wide uppercase text-[#2B2113] mb-2"
                    >
                      WhatsApp / Phone Number
                    </label>
                    <input
                      id="rsvp-phone"
                      type="tel"
                      required
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      placeholder="e.g. +91 98200 00000"
                      className="w-full min-h-[44px] rounded-md border border-[#C59B43]/50 bg-[#FFFFFF] px-4 py-2.5 text-sm text-[#2B2113] focus:border-[#9A6F20] focus:outline-none focus:ring-1 focus:ring-[#9A6F20]"
                    />
                  </div>
                </div>

                {/* Attendance Selection */}
                <div>
                  <span className="block text-xs font-medium tracking-wide uppercase text-[#2B2113] mb-2">
                    Will You Grace Us With Your Presence?
                  </span>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <button
                      type="button"
                      onClick={() => setAttending('yes')}
                      className={`min-h-[44px] px-4 py-3 rounded-md border text-sm font-medium text-left transition-colors cursor-pointer ${
                        attending === 'yes'
                          ? 'border-[#9A6F20] bg-[#9A6F20] text-[#FFFFFF]'
                          : 'border-[#C59B43]/50 bg-[#FFFFFF] text-[#2B2113] hover:bg-[#FAF6EE]'
                      }`}
                    >
                      InshaAllah, Joyfully Attending
                    </button>
                    <button
                      type="button"
                      onClick={() => setAttending('no')}
                      className={`min-h-[44px] px-4 py-3 rounded-md border text-sm font-medium text-left transition-colors cursor-pointer ${
                        attending === 'no'
                          ? 'border-[#9A6F20] bg-[#9A6F20] text-[#FFFFFF]'
                          : 'border-[#C59B43]/50 bg-[#FFFFFF] text-[#2B2113] hover:bg-[#FAF6EE]'
                      }`}
                    >
                      Unable to Attend · Sending Duas
                    </button>
                  </div>
                </div>

                {attending === 'yes' && (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                    <div>
                      <label
                        htmlFor="rsvp-guests"
                        className="block text-xs font-medium tracking-wide uppercase text-[#2B2113] mb-2"
                      >
                        Number of Guests
                      </label>
                      <select
                        id="rsvp-guests"
                        value={guestCount}
                        onChange={(e) => setGuestCount(Number(e.target.value))}
                        className="w-full min-h-[44px] rounded-md border border-[#C59B43]/50 bg-[#FFFFFF] px-4 py-2.5 text-sm text-[#2B2113] tabular-nums focus:border-[#9A6F20] focus:outline-none focus:ring-1 focus:ring-[#9A6F20]"
                      >
                        {[1, 2, 3, 4, 5, 6, 7, 8].map((num) => (
                          <option key={num} value={num}>
                            {num} {num === 1 ? 'Guest' : 'Guests'}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label
                        htmlFor="rsvp-ceremony"
                        className="block text-xs font-medium tracking-wide uppercase text-[#2B2113] mb-2"
                      >
                        Attending Session
                      </label>
                      <select
                        id="rsvp-ceremony"
                        value={ceremonyPreference}
                        onChange={(e) =>
                          setCeremonyPreference(
                            e.target.value as 'both' | 'nikah' | 'dinner',
                          )
                        }
                        className="w-full min-h-[44px] rounded-md border border-[#C59B43]/50 bg-[#FFFFFF] px-4 py-2.5 text-sm text-[#2B2113] focus:border-[#9A6F20] focus:outline-none focus:ring-1 focus:ring-[#9A6F20]"
                      >
                        <option value="both">Nikah &amp; Dinner (Full Evening)</option>
                        <option value="nikah">Nikah Ceremony (After Maghrib)</option>
                        <option value="dinner">Wedding Dinner (7:00 – 11:00 PM)</option>
                      </select>
                    </div>
                  </div>
                )}

                <div>
                  <label
                    htmlFor="rsvp-dua"
                    className="block text-xs font-medium tracking-wide uppercase text-[#2B2113] mb-2"
                  >
                    Dua or Blessing for Shabista &amp; Ataf (Optional)
                  </label>
                  <textarea
                    id="rsvp-dua"
                    rows={3}
                    maxLength={400}
                    value={duaMessage}
                    onChange={(e) => setDuaMessage(e.target.value)}
                    placeholder="Write a warm prayer or blessing for the couple..."
                    className="w-full rounded-md border border-[#C59B43]/50 bg-[#FFFFFF] px-4 py-2.5 text-sm text-[#2B2113] focus:border-[#9A6F20] focus:outline-none focus:ring-1 focus:ring-[#9A6F20]"
                  />
                  <label className="mt-2.5 inline-flex items-center gap-2.5 text-xs text-[#6B5B45] cursor-pointer">
                    <input
                      type="checkbox"
                      checked={shareDuaPublicly}
                      onChange={(e) => setShareDuaPublicly(e.target.checked)}
                      className="h-4 w-4 rounded border-[#C59B43] text-[#9A6F20] focus:ring-[#9A6F20]"
                    />
                    <span>Display my Dua &amp; name on the family blessings board</span>
                  </label>
                </div>

                {submitError && (
                  <p role="alert" className="text-sm font-medium text-[#8C4A18]">
                    {submitError}
                  </p>
                )}

                <div className="pt-2">
                  <button
                    type="submit"
                    disabled={submitting}
                    className="inline-flex items-center justify-center gap-2.5 min-h-[46px] w-full sm:w-auto px-8 py-3 rounded-md bg-[#9A6F20] text-[#FFFFFF] text-sm font-medium hover:bg-[#8C6318] transition-colors cursor-pointer disabled:opacity-60 whitespace-nowrap"
                  >
                    <Send className="w-4 h-4 text-[#F5E9CC]" />
                    <span>{submitting ? 'Saving RSVP...' : 'Confirm Attendance'}</span>
                  </button>
                </div>
              </form>
            )}
          </div>

          {/* Right Column: Real Confirmed Attendance & Family Duas Wall */}
          <aside className="lg:col-span-5 space-y-6">
            <div className="rounded-lg border border-[#C59B43]/55 bg-[#FFFFFF] text-[#2B2113] p-7 sm:p-8 shadow-[0_12px_32px_rgba(140,99,24,0.05)]">
              <div className="flex items-center justify-between gap-4">
                <p className="text-xs tracking-[0.22em] uppercase text-[#8C6318] font-medium">
                  Live Guest Register
                </p>
                <Users className="w-4 h-4 text-[#B38734]" aria-hidden="true" />
              </div>

              {summaryLoading ? (
                <p className="mt-4 text-sm text-[#6B5B45]">Loading confirmed responses...</p>
              ) : (
                <div className="mt-5 grid grid-cols-2 gap-6 border-t border-[#C59B43]/25 pt-5">
                  <div>
                    <div className="font-serif text-4xl font-semibold text-[#8C6318] tabular-nums">
                      {summary?.confirmedFamilies ?? 0}
                    </div>
                    <div className="mt-1 text-xs tracking-wide uppercase text-[#6B5B45]">
                      Confirmed Families
                    </div>
                  </div>
                  <div>
                    <div className="font-serif text-4xl font-semibold text-[#8C6318] tabular-nums">
                      {summary?.totalAttendingGuests ?? 0}
                    </div>
                    <div className="mt-1 text-xs tracking-wide uppercase text-[#6B5B45]">
                      Total Guests
                    </div>
                  </div>
                </div>
              )}
            </div>

            <div className="rounded-lg border border-[#C59B43]/50 bg-[#FFFFFF] p-7 sm:p-8 shadow-[0_12px_32px_rgba(140,99,24,0.05)]">
              <p className="text-xs tracking-[0.22em] uppercase text-[#8C6318] font-medium">
                Duas &amp; Blessings
              </p>
              <h3 className="mt-1.5 font-serif text-2xl font-medium text-[#2B2113]">
                Prayers from Loved Ones
              </h3>

              {summaryLoading ? (
                <p className="mt-4 text-sm text-[#6B5B45]">Loading blessings...</p>
              ) : summary && summary.publicBlessings.length > 0 ? (
                <ul className="mt-5 divide-y divide-[#C59B43]/20 max-h-[340px] overflow-y-auto pr-1">
                  {summary.publicBlessings.map((item) => (
                    <li key={item.id} className="py-4 first:pt-0 last:pb-0">
                      <p className="font-serif italic text-base text-[#2B2113] leading-relaxed">
                        “{item.duaMessage}”
                      </p>
                      <p className="mt-1.5 text-xs text-[#6B5B45]">
                        {item.guestName} ·{' '}
                        {item.attending === 'yes' ? 'Attending' : 'Sending Prayers'}
                      </p>
                    </li>
                  ))}
                </ul>
              ) : (
                <p className="mt-4 text-sm leading-relaxed text-[#6B5B45]">
                  Be the first to record your RSVP and share a heartfelt Dua for Sayyed Shabista
                  and Mohammad Ataf Momin.
                </p>
              )}
            </div>
          </aside>
        </div>
      </div>
    </section>
  );
}
