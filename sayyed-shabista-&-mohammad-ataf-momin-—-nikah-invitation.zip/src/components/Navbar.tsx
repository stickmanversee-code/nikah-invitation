import React, { useState } from 'react';
import { Menu, Share2, X } from 'lucide-react';
import { WEDDING_DETAILS } from '../data/weddingData';

interface NavbarProps {
  onOpenShare: () => void;
}

const NAV_LINKS = [
  { href: '#invitation', label: 'Invitation' },
  { href: '#schedule', label: 'Schedule' },
  { href: '#venue', label: 'Venue' },
  { href: '#gallery', label: 'Gallery' },
  { href: '#rsvp', label: 'RSVP' },
];

export function Navbar({ onOpenShare }: NavbarProps) {
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 border-b border-[#C59B43]/35 bg-[#FFFFFF]/94 backdrop-blur-md">
      <div className="mx-auto flex max-w-6xl items-center justify-between gap-8 px-4 sm:px-6 lg:px-8 h-16">
        {/* Zone 1: Single-line brand wordmark */}
        <a
          href="#invitation"
          className="font-serif text-xl sm:text-2xl font-semibold tracking-tight text-[#8C6318] whitespace-nowrap shrink-0"
        >
          {WEDDING_DETAILS.coupleShort}
        </a>

        {/* Zone 2: Concise single-line navigation links */}
        <nav
          aria-label="Primary Navigation"
          className="hidden md:flex items-center gap-7 text-sm font-medium text-[#6B5B45]"
        >
          {NAV_LINKS.map((link) => (
            <a
              key={link.href}
              href={link.href}
              className="relative py-1 hover:text-[#8C6318] transition-colors whitespace-nowrap shrink-0 after:absolute after:left-0 after:bottom-0 after:h-px after:w-0 after:bg-[#C59B43] hover:after:w-full after:transition-all after:duration-200"
            >
              {link.label}
            </a>
          ))}
        </nav>

        {/* Zone 3: Single primary action */}
        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={onOpenShare}
            className="inline-flex items-center gap-2 min-h-[40px] px-4 py-2 rounded-md bg-[#9A6F20] text-[#FFFFFF] text-xs sm:text-sm font-medium hover:bg-[#8C6318] transition-colors cursor-pointer whitespace-nowrap shrink-0"
          >
            <Share2 className="w-3.5 h-3.5 text-[#F5E9CC]" />
            <span>Share Invite</span>
          </button>

          <button
            type="button"
            onClick={() => setMobileOpen((prev) => !prev)}
            className="md:hidden inline-flex items-center justify-center w-10 h-10 rounded-md border border-[#C59B43]/45 text-[#8C6318] hover:bg-[#FAF6EE] transition-colors cursor-pointer"
            aria-expanded={mobileOpen}
            aria-label={mobileOpen ? 'Close navigation menu' : 'Open navigation menu'}
          >
            {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Clean Mobile Drawer */}
      {mobileOpen && (
        <nav
          aria-label="Mobile Navigation"
          className="md:hidden border-t border-[#C59B43]/25 bg-[#FFFFFF] px-4 py-3 flex flex-col gap-1"
        >
          {NAV_LINKS.map((link) => (
            <a
              key={link.href}
              href={link.href}
              onClick={() => setMobileOpen(false)}
              className="py-2.5 px-2 text-sm font-medium text-[#2B2113] hover:text-[#8C6318] hover:bg-[#FAF6EE] rounded-md transition-colors"
            >
              {link.label}
            </a>
          ))}
        </nav>
      )}
    </header>
  );
}
