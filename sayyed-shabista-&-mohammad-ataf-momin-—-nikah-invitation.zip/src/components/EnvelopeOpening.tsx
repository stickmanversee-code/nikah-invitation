import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ArrowRight } from 'lucide-react';
import {
  BismillahCalligraphy,
  CornerFloralArabesque,
  EngravedLatticeBackground,
  GoldGeometricDivider,
  WaxSealEmblem,
} from './IslamicOrnaments';
import { WEDDING_DETAILS } from '../data/weddingData';

interface EnvelopeOpeningProps {
  onOpenStart?: () => void;
  onComplete: () => void;
}

type OpeningStage = 'sealed' | 'opening' | 'reveal';

export function EnvelopeOpening({ onOpenStart, onComplete }: EnvelopeOpeningProps) {
  const [stage, setStage] = useState<OpeningStage>('sealed');

  useEffect(() => {
    if (stage === 'opening') {
      const revealTimer = window.setTimeout(() => {
        setStage('reveal');
      }, 1500);
      return () => window.clearTimeout(revealTimer);
    }

    if (stage === 'reveal') {
      const doneTimer = window.setTimeout(() => {
        onComplete();
      }, 3300);
      return () => window.clearTimeout(doneTimer);
    }
  }, [stage, onComplete]);

  const handleOpen = () => {
    if (stage !== 'sealed') return;
    onOpenStart?.();
    setStage('opening');
  };

  return (
    <div
      className="fixed inset-0 z-50 h-[100dvh] w-full overflow-hidden bg-[#FAF6EE] text-[#2B2113]"
      role="dialog"
      aria-modal="true"
      aria-label="Wedding Invitation Envelope"
    >
      <AnimatePresence mode="wait">
        {stage !== 'reveal' ? (
          <motion.div
            key="fullscreen-envelope"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0, scale: 1.02 }}
            transition={{ duration: 0.65, ease: [0.16, 1, 0.3, 1] }}
            className="relative h-full w-full perspective-1200 overflow-hidden"
          >
            {/* Full-Viewport Envelope Back Lining (Porcelain White & Soft Gold Shimmer) */}
            <div
              className="absolute inset-0"
              style={{
                background:
                  'radial-gradient(circle at 50% 42%, #FFFFFF 0%, #FAF5EA 55%, #EFE5D1 100%)',
              }}
            />

            {/* Engraved Golden Geometric Lattice Etched Across Envelope */}
            <EngravedLatticeBackground className="absolute inset-0 opacity-85" />

            {/* Rising Porcelain White & Engraved Gold Inner Invitation Card */}
            <motion.div
              initial={false}
              animate={
                stage === 'opening'
                  ? { y: '-4%', opacity: 1, scale: 1 }
                  : { y: '34%', opacity: 0.98, scale: 0.96 }
              }
              transition={{
                delay: stage === 'opening' ? 0.42 : 0,
                duration: 0.95,
                ease: [0.16, 1, 0.3, 1],
              }}
              className="absolute inset-x-3 sm:inset-x-10 md:inset-x-auto md:left-1/2 md:-translate-x-1/2 md:w-full md:max-w-3xl top-6 bottom-6 z-10 rounded-lg bg-[#FFFFFF] border-2 border-[#C59B43]/80 shadow-[0_24px_70px_rgba(140,99,24,0.22)] p-3 sm:p-5 flex"
            >
              <div className="relative flex w-full flex-col items-center justify-center rounded-md border border-[#C59B43]/45 bg-gradient-to-b from-[#FFFFFF] via-[#FCF9F2] to-[#FFFFFF] px-6 py-8 text-center">
                <CornerFloralArabesque className="pointer-events-none absolute top-2 left-2 w-14 h-14 sm:w-20 sm:h-20 text-[#C59B43]" />
                <CornerFloralArabesque
                  className="pointer-events-none absolute top-2 right-2 w-14 h-14 sm:w-20 sm:h-20 text-[#C59B43]"
                  flipX
                />
                <CornerFloralArabesque
                  className="pointer-events-none absolute bottom-2 left-2 w-14 h-14 sm:w-20 sm:h-20 text-[#C59B43]"
                  flipY
                />
                <CornerFloralArabesque
                  className="pointer-events-none absolute bottom-2 right-2 w-14 h-14 sm:w-20 sm:h-20 text-[#C59B43]"
                  flipX
                  flipY
                />

                <p
                  dir="rtl"
                  lang="ar"
                  className="text-2xl sm:text-3xl md:text-4xl text-[#8C6318]"
                  style={{ fontFamily: 'var(--font-arabic)' }}
                >
                  بِسْمِ ٱللَّٰهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ
                </p>
                <div className="my-4 h-px w-24 bg-[#C59B43]/60" />
                <p className="text-xs tracking-[0.26em] uppercase text-[#8C6318]">
                  Nikah Invitation
                </p>
                <p className="mt-3 font-serif text-3xl sm:text-4xl md:text-5xl font-semibold text-[#2B2113]">
                  {WEDDING_DETAILS.bride}
                </p>
                <p className="my-1 font-serif italic text-2xl text-[#B38734]">&amp;</p>
                <p className="font-serif text-3xl sm:text-4xl md:text-5xl font-semibold text-[#2B2113]">
                  {WEDDING_DETAILS.groom}
                </p>
                <p className="mt-5 text-xs sm:text-sm tracking-[0.2em] uppercase text-[#6B5B45]">
                  {WEDDING_DETAILS.dateDisplay}
                </p>
              </div>
            </motion.div>

            {/* Full-Viewport White & Engraved Gold Lower Pocket Flaps */}
            <svg
              viewBox="0 0 1000 1000"
              preserveAspectRatio="none"
              className="pointer-events-none absolute inset-0 h-full w-full z-20"
              aria-hidden="true"
            >
              <defs>
                <linearGradient id="whitePocketLeft" x1="0" y1="0" x2="1" y2="1">
                  <stop offset="0%" stopColor="#FFFFFF" />
                  <stop offset="100%" stopColor="#F4ECE0" />
                </linearGradient>
                <linearGradient id="whitePocketRight" x1="1" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#FFFFFF" />
                  <stop offset="100%" stopColor="#F2E9DA" />
                </linearGradient>
                <linearGradient id="whitePocketBottom" x1="0.5" y1="0" x2="0.5" y2="1">
                  <stop offset="0%" stopColor="#FFFFFF" />
                  <stop offset="100%" stopColor="#FAF5EB" />
                </linearGradient>
              </defs>

              {/* Left, Right & Bottom Porcelain Paper Flaps */}
              <polygon points="0,0 500,520 0,1000" fill="url(#whitePocketLeft)" />
              <polygon points="1000,0 500,520 1000,1000" fill="url(#whitePocketRight)" />
              <polygon points="0,1000 500,485 1000,1000" fill="url(#whitePocketBottom)" />

              {/* Engraved Champagne Gold Foil Seam Lines */}
              <polyline
                points="0,1000 500,485 1000,1000"
                fill="none"
                stroke="#C59B43"
                strokeOpacity="0.85"
                strokeWidth="2.5"
              />
              <polyline
                points="0,982 500,501 1000,982"
                fill="none"
                stroke="#C59B43"
                strokeOpacity="0.4"
                strokeWidth="1.2"
              />
              <line
                x1="0"
                y1="0"
                x2="500"
                y2="520"
                stroke="#C59B43"
                strokeOpacity="0.45"
                strokeWidth="1.5"
              />
              <line
                x1="1000"
                y1="0"
                x2="500"
                y2="520"
                stroke="#C59B43"
                strokeOpacity="0.45"
                strokeWidth="1.5"
              />
            </svg>

            {/* Full-Viewport Top Triangular Flap (White Cardstock + Gold Foil Engraving) */}
            <motion.div
              initial={false}
              animate={
                stage === 'opening'
                  ? { rotateX: 175, opacity: 0.35, zIndex: 5 }
                  : { rotateX: 0, opacity: 1, zIndex: 30 }
              }
              transition={{
                duration: 0.78,
                ease: [0.16, 1, 0.3, 1],
              }}
              style={{ transformOrigin: 'top center' }}
              className="pointer-events-none absolute inset-x-0 top-0 h-[55%] preserve-3d"
            >
              <svg
                viewBox="0 0 1000 550"
                preserveAspectRatio="none"
                className="h-full w-full drop-shadow-[0_14px_28px_rgba(140,99,24,0.18)]"
                aria-hidden="true"
              >
                <defs>
                  <linearGradient id="whiteTopFlapGrad" x1="0.5" y1="0" x2="0.5" y2="1">
                    <stop offset="0%" stopColor="#FAF6EE" />
                    <stop offset="55%" stopColor="#FFFFFF" />
                    <stop offset="100%" stopColor="#FAF4E8" />
                  </linearGradient>
                </defs>
                <polygon points="0,0 1000,0 500,535" fill="url(#whiteTopFlapGrad)" />
                {/* Double Engraved Gold Foil Border */}
                <polyline
                  points="0,0 500,535 1000,0"
                  fill="none"
                  stroke="#C59B43"
                  strokeOpacity="0.9"
                  strokeWidth="3"
                />
                <polyline
                  points="30,0 500,502 970,0"
                  fill="none"
                  stroke="#C59B43"
                  strokeOpacity="0.45"
                  strokeWidth="1.4"
                />
              </svg>

              {/* Header Invitation Text Seated on the White & Gold Engraved Flap */}
              <div className="absolute inset-x-0 top-10 sm:top-14 flex flex-col items-center text-center px-6">
                <p className="text-[11px] sm:text-xs tracking-[0.32em] uppercase text-[#8C6318] font-medium">
                  Nikah Invitation
                </p>
                <h1 className="mt-2.5 font-serif text-3xl sm:text-5xl font-medium tracking-tight text-[#2B2113]">
                  You Are Cordially Invited
                </h1>
                <p className="mt-2 text-xs sm:text-sm tracking-[0.18em] uppercase text-[#6B5B45]">
                  {WEDDING_DETAILS.dateDisplay}
                </p>
              </div>
            </motion.div>

            {/* Four Corner Engraved Gold Filigree */}
            <CornerFloralArabesque className="pointer-events-none absolute top-3 left-3 z-40 w-16 h-16 sm:w-24 sm:h-24 text-[#C59B43]" />
            <CornerFloralArabesque
              className="pointer-events-none absolute top-3 right-3 z-40 w-16 h-16 sm:w-24 sm:h-24 text-[#C59B43]"
              flipX
            />
            <CornerFloralArabesque
              className="pointer-events-none absolute bottom-3 left-3 z-40 w-16 h-16 sm:w-24 sm:h-24 text-[#C59B43]"
              flipY
            />
            <CornerFloralArabesque
              className="pointer-events-none absolute bottom-3 right-3 z-40 w-16 h-16 sm:w-24 sm:h-24 text-[#C59B43]"
              flipX
              flipY
            />

            {/* Interactive Center Wax Seal Button (Simple, Classic S & A) + Tap to Open */}
            <div className="absolute inset-x-0 top-[49%] z-40 flex flex-col items-center -translate-y-1/4 px-4">
              <motion.button
                type="button"
                onClick={handleOpen}
                disabled={stage !== 'sealed'}
                initial={false}
                animate={
                  stage === 'opening'
                    ? { scale: 0.78, opacity: 0, y: -18 }
                    : { scale: 1, opacity: 1, y: 0 }
                }
                transition={{ duration: 0.42, ease: [0.16, 1, 0.3, 1] }}
                aria-label="Tap S and A seal to open wedding invitation"
                className="group relative flex items-center justify-center rounded-full cursor-pointer focus:outline-none focus-visible:ring-4 focus-visible:ring-[#C59B43]/60 active:scale-95 transition-transform"
              >
                <WaxSealEmblem className="w-36 h-36 sm:w-44 sm:h-44 drop-shadow-[0_14px_30px_rgba(140,99,24,0.32)] transition-transform duration-200 group-hover:scale-105" />
              </motion.button>

              <motion.div
                initial={false}
                animate={stage === 'opening' ? { opacity: 0, y: 8 } : { opacity: 1, y: 0 }}
                transition={{ duration: 0.3 }}
                className="mt-6 flex flex-col items-center text-center"
              >
                <button
                  type="button"
                  onClick={handleOpen}
                  disabled={stage !== 'sealed'}
                  className="inline-flex items-center justify-center gap-3 min-h-[48px] px-8 py-3 rounded-md bg-[#9A6F20] text-[#FFFFFF] font-medium text-sm sm:text-base tracking-wide shadow-[0_12px_28px_rgba(140,99,24,0.28)] hover:bg-[#8C6318] active:scale-[0.98] transition-all cursor-pointer whitespace-nowrap"
                >
                  <span className="font-serif text-lg font-semibold tracking-widest">
                    S &amp; A
                  </span>
                  <span className="h-4 w-px bg-[#FFFFFF]/35" aria-hidden="true" />
                  <span>Tap to Open</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
                <p className="mt-3 font-serif italic text-sm sm:text-base text-[#6B5B45]">
                  Press S &amp; A to unveil your invitation
                </p>
              </motion.div>
            </div>
          </motion.div>
        ) : (
          <motion.div
            key="bismillah-reveal"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.7 }}
            className="relative z-10 flex h-full w-full flex-col items-center justify-center text-center px-6 bg-[#FFFFFF]"
            style={{
              background:
                'radial-gradient(circle at 50% 45%, #FFFFFF 0%, #FAF5EA 75%, #F2E8D5 100%)',
            }}
          >
            <EngravedLatticeBackground className="absolute inset-0 opacity-60" />

            <CornerFloralArabesque className="pointer-events-none absolute top-4 left-4 w-16 h-16 sm:w-24 sm:h-24 text-[#C59B43]" />
            <CornerFloralArabesque
              className="pointer-events-none absolute top-4 right-4 w-16 h-16 sm:w-24 sm:h-24 text-[#C59B43]"
              flipX
            />
            <CornerFloralArabesque
              className="pointer-events-none absolute bottom-4 left-4 w-16 h-16 sm:w-24 sm:h-24 text-[#C59B43]"
              flipY
            />
            <CornerFloralArabesque
              className="pointer-events-none absolute bottom-4 right-4 w-16 h-16 sm:w-24 sm:h-24 text-[#C59B43]"
              flipX
              flipY
            />

            <div className="relative z-10 max-w-2xl">
              <motion.div
                initial={{ opacity: 0, y: 18 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
              >
                <BismillahCalligraphy />
              </motion.div>

              <motion.div
                initial={{ opacity: 0, scaleX: 0.6 }}
                animate={{ opacity: 1, scaleX: 1 }}
                transition={{ delay: 0.45, duration: 0.7 }}
                className="w-full max-w-xs mx-auto my-8"
              >
                <GoldGeometricDivider />
              </motion.div>

              <motion.p
                initial={{ opacity: 0, y: 14 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.65, duration: 0.75 }}
                className="text-xs sm:text-sm tracking-[0.26em] uppercase text-[#8C6318]"
              >
                The Blessed Union Of
              </motion.p>

              <motion.h2
                initial={{ opacity: 0, y: 18, scale: 0.96 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                transition={{ delay: 0.9, duration: 0.85, ease: [0.16, 1, 0.3, 1] }}
                className="mt-4 font-serif text-4xl sm:text-5xl md:text-6xl font-semibold text-[#8C6318] leading-tight"
              >
                {WEDDING_DETAILS.bride}
              </motion.h2>

              <motion.span
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 1.2, duration: 0.6 }}
                className="block my-2 font-serif italic text-2xl sm:text-3xl text-[#C59B43]"
              >
                &amp;
              </motion.span>

              <motion.h2
                initial={{ opacity: 0, y: 18, scale: 0.96 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                transition={{ delay: 1.4, duration: 0.85, ease: [0.16, 1, 0.3, 1] }}
                className="font-serif text-4xl sm:text-5xl md:text-6xl font-semibold text-[#8C6318] leading-tight"
              >
                {WEDDING_DETAILS.groom}
              </motion.h2>

              <motion.div
                initial={{ opacity: 0, scaleX: 0 }}
                animate={{ opacity: 1, scaleX: 1 }}
                transition={{ delay: 1.65, duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
                className="mx-auto mt-5 h-px w-40 bg-gradient-to-r from-transparent via-[#C59B43] to-transparent"
              />

              <motion.div
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 1.9, duration: 0.65 }}
                className="mt-10"
              >
                <button
                  type="button"
                  onClick={onComplete}
                  className="inline-flex items-center gap-2 min-h-[44px] px-7 py-2.5 rounded-md border border-[#C59B43] bg-[#FFFFFF] text-[#8C6318] text-sm font-medium hover:bg-[#FAF6EE] transition-colors cursor-pointer whitespace-nowrap"
                >
                  <span>Enter Invitation</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </motion.div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
