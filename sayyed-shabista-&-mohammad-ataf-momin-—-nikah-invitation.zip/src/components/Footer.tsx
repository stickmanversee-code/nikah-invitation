import React from 'react';
import { MessageCircle, RotateCcw } from 'lucide-react';
import { WEDDING_DETAILS, buildWhatsAppShareUrl } from '../data/weddingData';
import { GoldGeometricDivider } from './IslamicOrnaments';

interface FooterProps {
  onReplayEnvelope: () => void;
}

export function Footer({ onReplayEnvelope }: FooterProps) {
  const shareUrl = typeof window !== 'undefined' ? window.location.origin : '';
  const whatsappUrl = buildWhatsAppShareUrl(shareUrl);

  return (
    <footer className="bg-[#FFFFFF] text-[#2B2113] py-14 sm:py-16 border-t border-[#C59B43]/40">
      <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8 text-center">
        <p
          dir="rtl"
          lang="ar"
          className="text-2xl sm:text-3xl text-[#8C6318]"
          style={{ fontFamily: 'var(--font-arabic)' }}
        >
          بَارَكَ اللَّهُ لَكُمَا وَبَارَكَ عَلَيْكُمَا وَجَمَعَ بَيْنَكُمَا فِي خَيْرٍ
        </p>
        <p className="mt-2 text-xs sm:text-sm text-[#6B5B45] max-w-xl mx-auto">
          May Allah bless you both, shower His blessings upon you, and unite you together in
          goodness.
        </p>

        <GoldGeometricDivider className="my-8 max-w-xs mx-auto" />

        <h2 className="font-serif text-3xl sm:text-4xl font-medium text-[#2B2113]">
          {WEDDING_DETAILS.bride} &amp; {WEDDING_DETAILS.groom}
        </h2>
        <p className="mt-2 text-sm text-[#6B5B45]">
          {WEDDING_DETAILS.dateDisplay} · {WEDDING_DETAILS.venueName}, Mumbra, Thane
        </p>

        <div className="mt-8 flex flex-wrap items-center justify-center gap-4">
          <a
            href={whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center justify-center gap-2 min-h-[44px] px-6 py-2.5 rounded-md bg-[#9A6F20] text-[#FFFFFF] text-sm font-medium hover:bg-[#8C6318] transition-colors whitespace-nowrap"
          >
            <MessageCircle className="w-4 h-4 text-[#F5E9CC]" />
            <span>Share on WhatsApp</span>
          </a>

          <button
            type="button"
            onClick={onReplayEnvelope}
            className="inline-flex items-center justify-center gap-2 min-h-[44px] px-5 py-2.5 rounded-md border border-[#C59B43]/75 text-[#8C6318] text-sm font-medium hover:bg-[#FAF6EE] transition-colors cursor-pointer whitespace-nowrap"
          >
            <RotateCcw className="w-4 h-4" />
            <span>Replay Envelope</span>
          </button>
        </div>
      </div>
    </footer>
  );
}
