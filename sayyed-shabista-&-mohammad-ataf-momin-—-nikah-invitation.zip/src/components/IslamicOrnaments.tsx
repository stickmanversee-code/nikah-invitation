import React from 'react';

export function GoldGeometricDivider({ className = '' }: { className?: string }) {
  return (
    <div className={`flex items-center justify-center gap-4 ${className}`} aria-hidden="true">
      <div className="h-px flex-1 max-w-28 bg-gradient-to-r from-transparent to-[#C59B43]/65" />
      <svg
        width="32"
        height="32"
        viewBox="0 0 32 32"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="text-[#B38734] shrink-0"
      >
        <path
          d="M16 3L19.6 12.4L29 16L19.6 19.6L16 29L12.4 19.6L3 16L12.4 12.4L16 3Z"
          stroke="currentColor"
          strokeWidth="1"
        />
        <rect
          x="10"
          y="10"
          width="12"
          height="12"
          transform="rotate(45 16 16)"
          stroke="currentColor"
          strokeWidth="0.85"
          opacity="0.7"
        />
        <circle cx="16" cy="16" r="2.2" fill="currentColor" opacity="0.85" />
      </svg>
      <div className="h-px flex-1 max-w-28 bg-gradient-to-l from-transparent to-[#C59B43]/65" />
    </div>
  );
}

export function CornerFloralArabesque({
  className = '',
  flipX = false,
  flipY = false,
}: {
  className?: string;
  flipX?: boolean;
  flipY?: boolean;
}) {
  const scaleX = flipX ? -1 : 1;
  const scaleY = flipY ? -1 : 1;
  return (
    <svg
      width="96"
      height="96"
      viewBox="0 0 96 96"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      style={{ transform: `scale(${scaleX}, ${scaleY})` }}
      aria-hidden="true"
    >
      <path
        d="M8 88V36C8 20.536 20.536 8 36 8H88"
        stroke="currentColor"
        strokeWidth="1.2"
        opacity="0.8"
      />
      <path
        d="M14 88V40C14 25.64 25.64 14 40 14H88"
        stroke="currentColor"
        strokeWidth="0.8"
        opacity="0.5"
      />
      <path
        d="M22 22C28 22 33 17 33 11C33 17 38 22 44 22C38 22 33 27 33 33C33 27 28 22 22 22Z"
        stroke="currentColor"
        strokeWidth="0.95"
        opacity="0.85"
      />
      <path
        d="M11 33C17 33 22 28 22 22C22 28 27 33 33 33C27 33 22 38 22 44C22 38 17 33 11 33Z"
        stroke="currentColor"
        strokeWidth="0.95"
        opacity="0.6"
      />
      <circle cx="14" cy="14" r="2.2" fill="currentColor" opacity="0.9" />
    </svg>
  );
}

export function EngravedLatticeBackground({ className = '' }: { className?: string }) {
  return (
    <svg
      className={`pointer-events-none ${className}`}
      width="100%"
      height="100%"
      xmlns="http://www.w3.org/2000/svg"
      aria-hidden="true"
    >
      <defs>
        <pattern
          id="goldEngravedLattice"
          width="64"
          height="64"
          patternUnits="userSpaceOnUse"
        >
          <path
            d="M32 4L40 24L60 32L40 40L32 60L24 40L4 32L24 24L32 4Z"
            fill="none"
            stroke="#C59B43"
            strokeWidth="0.65"
            strokeOpacity="0.22"
          />
          <circle
            cx="32"
            cy="32"
            r="6"
            fill="none"
            stroke="#C59B43"
            strokeWidth="0.55"
            strokeOpacity="0.2"
          />
          <circle cx="0" cy="0" r="3" fill="none" stroke="#C59B43" strokeWidth="0.5" strokeOpacity="0.18" />
          <circle cx="64" cy="0" r="3" fill="none" stroke="#C59B43" strokeWidth="0.5" strokeOpacity="0.18" />
          <circle cx="0" cy="64" r="3" fill="none" stroke="#C59B43" strokeWidth="0.5" strokeOpacity="0.18" />
          <circle cx="64" cy="64" r="3" fill="none" stroke="#C59B43" strokeWidth="0.5" strokeOpacity="0.18" />
        </pattern>
      </defs>
      <rect width="100%" height="100%" fill="url(#goldEngravedLattice)" />
    </svg>
  );
}

export function WaxSealEmblem({ className = '' }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 160 160"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      aria-hidden="true"
    >
      <defs>
        <radialGradient id="whiteGoldSealOuter" cx="34%" cy="28%" r="72%">
          <stop offset="0%" stopColor="#FFF7DC" />
          <stop offset="38%" stopColor="#E6C67D" />
          <stop offset="76%" stopColor="#BD923A" />
          <stop offset="100%" stopColor="#85601A" />
        </radialGradient>
        <radialGradient id="whiteGoldSealInner" cx="50%" cy="45%" r="58%">
          <stop offset="0%" stopColor="#FFFFFF" />
          <stop offset="68%" stopColor="#FAF3E3" />
          <stop offset="100%" stopColor="#EAD7AB" />
        </radialGradient>
      </defs>

      {/* Outer scalloped wax & gold foil silhouette */}
      <path
        d="M80 7C89 11 97 8 106 14C114 20 124 22 130 30C136 38 144 45 147 55C151 64 155 72 153 82C152 92 149 101 144 110C139 119 134 128 126 134C118 140 109 147 99 150C89 153 79 155 69 153C59 151 50 147 41 141C32 136 22 129 17 119C11 109 6 100 6 89C6 78 8 69 12 59C15 49 20 39 28 31C36 23 44 16 54 12C64 9 72 4 80 7Z"
        fill="url(#whiteGoldSealOuter)"
      />

      {/* Crisp porcelain-white & gold-engraved center medallion */}
      <circle
        cx="80"
        cy="80"
        r="58"
        fill="url(#whiteGoldSealInner)"
        stroke="#9A6F20"
        strokeWidth="1.6"
      />
      <circle
        cx="80"
        cy="80"
        r="51"
        stroke="#C59B43"
        strokeWidth="1"
        strokeDasharray="2.5 3.5"
        opacity="0.9"
      />
      <circle
        cx="80"
        cy="80"
        r="46"
        stroke="#C59B43"
        strokeWidth="0.7"
        opacity="0.45"
      />

      {/* Top & bottom engraved diamond */}
      <path d="M80 27L82.5 31L80 35L77.5 31L80 27Z" fill="#B38734" opacity="0.85" />
      <path d="M80 125L82.5 129L80 133L77.5 129L80 125Z" fill="#B38734" opacity="0.85" />

      {/* Simple, Clean, Classic Serif S & A Alphabets */}
      <text
        x="80"
        y="91"
        textAnchor="middle"
        fill="#7A5614"
        fontFamily="'Cormorant Garamond', Georgia, serif"
        fontSize="36"
        fontWeight="600"
        letterSpacing="4"
      >
        S &amp; A
      </text>
    </svg>
  );
}

export function BismillahCalligraphy({
  className = '',
}: {
  variant?: 'dark' | 'light';
  className?: string;
}) {
  return (
    <div className={`text-center ${className}`}>
      <p
        dir="rtl"
        lang="ar"
        className="text-3xl sm:text-4xl md:text-[2.75rem] leading-relaxed tracking-normal text-[#8C6318]"
        style={{ fontFamily: 'var(--font-arabic)' }}
      >
        بِسْمِ ٱللَّٰهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ
      </p>
      <p className="mt-2 text-xs sm:text-sm tracking-[0.18em] uppercase text-[#6B5B45]">
        In the name of Allah, the Most Gracious, the Most Merciful
      </p>
    </div>
  );
}

export function IslamicArchFrame({
  children,
  className = '',
}: {
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <div
      className={`relative p-2.5 border border-[#C59B43]/60 rounded-t-[180px] rounded-b-lg bg-[#FAF6EE] ${className}`}
    >
      <div className="relative overflow-hidden rounded-t-[170px] rounded-b-md border border-[#C59B43]/35 h-full">
        {children}
      </div>
    </div>
  );
}
