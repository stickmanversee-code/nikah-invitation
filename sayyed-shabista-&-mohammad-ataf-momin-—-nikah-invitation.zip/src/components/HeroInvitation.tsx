import React, { useState } from 'react';
import { motion } from 'motion/react';
import { MapPin, CalendarCheck } from 'lucide-react';
import {
  BismillahCalligraphy,
  GoldGeometricDivider,
  IslamicArchFrame,
} from './IslamicOrnaments';
import { WEDDING_DETAILS } from '../data/weddingData';

export function HeroInvitation() {
  const [imgError, setImgError] = useState(false);

  return (
    <section
      id="invitation"
      className="relative overflow-hidden border-b border-[#C59B43]/30 bg-[#FFFFFF] pt-10 pb-14 sm:pt-14 sm:pb-20"
    >
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        {/* Bismillah Header */}
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.65, ease: [0.16, 1, 0.3, 1] }}
          className="pb-8 sm:pb-10"
        >
          <BismillahCalligraphy />
        </motion.div>

        {/* 2-Column Editorial Hero Split */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-stretch">
          {/* Left Column: Welcome & Couple Names */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.75, delay: 0.1, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-7 flex flex-col justify-center text-center lg:text-left"
          >
            <p className="text-xs sm:text-sm tracking-[0.24em] uppercase text-[#8C6318] font-medium">
              With the Grace &amp; Blessings of Allah (SWT)
            </p>

            <p className="mt-4 text-base sm:text-lg leading-relaxed text-[#6B5B45] max-w-xl mx-auto lg:mx-0">
              Together with their beloved families, we joyfully request the honour of your presence
              and heartfelt duas on the auspicious occasion of the Nikah ceremony of
            </p>

            <div className="mt-8 sm:mt-10">
              <h1 className="font-serif text-4xl sm:text-5xl lg:text-[3.5rem] font-semibold text-[#2B2113] leading-[1.12] tracking-tight">
                {WEDDING_DETAILS.bride}
              </h1>
              <div className="my-3 flex items-center justify-center lg:justify-start gap-4">
                <span className="h-px w-10 bg-[#C59B43]/65" aria-hidden="true" />
                <span className="font-serif italic text-2xl sm:text-3xl text-[#B38734]">
                  &amp;
                </span>
                <span className="h-px w-10 bg-[#C59B43]/65" aria-hidden="true" />
              </div>
              <h2 className="font-serif text-4xl sm:text-5xl lg:text-[3.5rem] font-semibold text-[#2B2113] leading-[1.12] tracking-tight">
                {WEDDING_DETAILS.groom}
              </h2>
            </div>

            {/* Quranic Verse Pull Quote */}
            <div className="mt-8 pt-6 border-t border-b border-[#C59B43]/35 py-5 max-w-xl mx-auto lg:mx-0">
              <p className="font-serif italic text-lg sm:text-xl text-[#2B2113] leading-relaxed">
                “And of His signs is that He created for you from yourselves mates that you may
                find tranquillity in them; and He placed between you affection and mercy.”
              </p>
              <p className="mt-2 text-xs tracking-[0.18em] uppercase text-[#8C6318]">
                Surah Ar-Rum · 30:21
              </p>
            </div>

            {/* Primary & Secondary Actions */}
            <div className="mt-8 flex flex-wrap items-center justify-center lg:justify-start gap-4">
              <a
                href="#rsvp"
                className="inline-flex items-center justify-center gap-2 min-h-[44px] px-7 py-3 rounded-md bg-[#9A6F20] text-[#FFFFFF] text-sm font-medium hover:bg-[#8C6318] transition-colors whitespace-nowrap"
              >
                <CalendarCheck className="w-4 h-4 text-[#F5E9CC]" />
                <span>Confirm Your RSVP</span>
              </a>

              <a
                href={WEDDING_DETAILS.googleMapsUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center gap-2 min-h-[44px] px-6 py-3 rounded-md border border-[#C59B43]/75 text-[#8C6318] text-sm font-medium hover:bg-[#FAF6EE] transition-colors whitespace-nowrap"
              >
                <MapPin className="w-4 h-4 text-[#B38734]" />
                <span>Get Venue Directions</span>
              </a>
            </div>
          </motion.div>

          {/* Right Column: Arched White & Gold Islamic Venue Decor Photograph */}
          <motion.div
            initial={{ opacity: 0, scale: 0.98 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.85, delay: 0.2, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-5 flex"
          >
            <IslamicArchFrame className="w-full min-h-[340px] sm:min-h-[420px] lg:min-h-full">
              {!imgError ? (
                <img
                  src="/src/assets/images/white_gold_decor_1795539447817.jpg"
                  alt="White and gold Islamic Nikah hall with ivory silk drapes, golden Moroccan lanterns, and white roses"
                  referrerPolicy="no-referrer"
                  onError={() => setImgError(true)}
                  className="h-full w-full object-cover"
                />
              ) : (
                <div className="flex h-full w-full flex-col items-center justify-center bg-gradient-to-b from-[#FAF6EE] to-[#EFE5D1] p-8 text-center text-[#8C6318]">
                  <p className="font-serif text-2xl">Noor Baug Hall</p>
                  <p className="mt-2 text-xs tracking-widest uppercase opacity-80">
                    Kausa, Mumbra, Thane
                  </p>
                </div>
              )}
              <div className="pointer-events-none absolute inset-x-0 bottom-0 bg-gradient-to-t from-[#2B2113]/80 via-[#2B2113]/25 to-transparent p-6 text-[#FFFFFF]">
                <p className="text-xs tracking-[0.2em] uppercase text-[#F5E9CC]">
                  The Sanctuary
                </p>
                <p className="mt-1 font-serif text-lg">
                  {WEDDING_DETAILS.venueName}, Mumbra
                </p>
              </div>
            </IslamicArchFrame>
          </motion.div>
        </div>

        {/* Full-Width 4-Column Ceremonial Summary Strip */}
        <div className="mt-12 sm:mt-14 pt-8 border-t border-[#C59B43]/30">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 text-center sm:text-left">
            <div className="px-2">
              <p className="text-xs tracking-[0.18em] uppercase text-[#8C6318]">
                Wedding Date
              </p>
              <p className="mt-1.5 font-serif text-xl font-medium text-[#2B2113]">
                {WEDDING_DETAILS.dateDisplay}
              </p>
            </div>
            <div className="px-2">
              <p className="text-xs tracking-[0.18em] uppercase text-[#8C6318]">
                Nikah Ceremony
              </p>
              <p className="mt-1.5 font-serif text-xl font-medium text-[#2B2113]">
                {WEDDING_DETAILS.nikahTime}
              </p>
            </div>
            <div className="px-2">
              <p className="text-xs tracking-[0.18em] uppercase text-[#8C6318]">
                Wedding Dinner
              </p>
              <p className="mt-1.5 font-serif text-xl font-medium text-[#2B2113]">
                {WEDDING_DETAILS.dinnerTime}
              </p>
            </div>
            <div className="px-2">
              <p className="text-xs tracking-[0.18em] uppercase text-[#8C6318]">
                Venue Location
              </p>
              <p className="mt-1.5 font-serif text-xl font-medium text-[#2B2113]">
                {WEDDING_DETAILS.venueName}, Mumbra
              </p>
            </div>
          </div>
        </div>

        <GoldGeometricDivider className="mt-10" />
      </div>
    </section>
  );
}
