import React, { useEffect, useState } from 'react';
import { ChevronLeft, ChevronRight, X, Maximize2 } from 'lucide-react';
import { GALLERY_ITEMS, GalleryItem } from '../data/weddingData';

type FilterCategory = 'all' | 'attire' | 'details';

export function PhotoGallery() {
  const [filter, setFilter] = useState<FilterCategory>('all');
  const [activeIndex, setActiveIndex] = useState<number | null>(null);
  const [failedImages, setFailedImages] = useState<Record<string, boolean>>({});

  const visibleItems =
    filter === 'all'
      ? GALLERY_ITEMS
      : GALLERY_ITEMS.filter((item) => item.category === filter);

  useEffect(() => {
    if (activeIndex === null) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setActiveIndex(null);
      } else if (e.key === 'ArrowRight') {
        setActiveIndex((prev) =>
          prev === null ? null : (prev + 1) % visibleItems.length,
        );
      } else if (e.key === 'ArrowLeft') {
        setActiveIndex((prev) =>
          prev === null ? null : (prev - 1 + visibleItems.length) % visibleItems.length,
        );
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [activeIndex, visibleItems.length]);

  const markFailed = (id: string) => {
    setFailedImages((prev) => ({ ...prev, [id]: true }));
  };

  const activeItem: GalleryItem | null =
    activeIndex !== null && visibleItems[activeIndex] ? visibleItems[activeIndex] : null;

  return (
    <section id="gallery" className="bg-[#FFFFFF] py-16 sm:py-24">
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        {/* Header & Interactive Filter Controls */}
        <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-6 pb-8 border-b border-[#C59B43]/30">
          <div>
            <p className="text-xs sm:text-sm tracking-[0.26em] uppercase text-[#8C6318] font-medium">
              Curated Visuals
            </p>
            <h2 className="mt-2 font-serif text-3xl sm:text-4xl md:text-5xl font-medium text-[#2B2113]">
              Moments in Grace &amp; Modesty
            </h2>
          </div>

          <div
            role="tablist"
            aria-label="Filter photo gallery"
            className="inline-flex items-center gap-1 p-1 rounded-lg bg-[#FAF6EE] border border-[#C59B43]/35 self-start md:self-auto"
          >
            {(
              [
                { id: 'all', label: 'All Photographs' },
                { id: 'attire', label: 'Bride & Groom' },
                { id: 'details', label: 'Sanctuary & Details' },
              ] as const
            ).map((tab) => (
              <button
                key={tab.id}
                type="button"
                role="tab"
                aria-selected={filter === tab.id}
                onClick={() => {
                  setFilter(tab.id);
                  setActiveIndex(null);
                }}
                className={`px-3.5 py-2 text-xs sm:text-sm font-medium rounded-md transition-colors cursor-pointer whitespace-nowrap shrink-0 ${
                  filter === tab.id
                    ? 'bg-[#9A6F20] text-[#FFFFFF]'
                    : 'text-[#6B5B45] hover:text-[#8C6318]'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {/* Responsive Editorial Grid */}
        <div className="mt-10 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {visibleItems.map((item, idx) => {
            const isWideFirst = filter === 'all' && idx === 0;
            return (
              <figure
                key={item.id}
                className={`group relative overflow-hidden rounded-lg border border-[#C59B43]/40 bg-[#FAF6EE] ${
                  isWideFirst ? 'sm:col-span-2 lg:col-span-2 aspect-[16/10]' : 'aspect-[4/5] sm:aspect-[4/4]'
                }`}
              >
                <button
                  type="button"
                  onClick={() => setActiveIndex(idx)}
                  className="relative block h-full w-full text-left cursor-pointer focus:outline-none focus-visible:ring-2 focus-visible:ring-[#8C6318]"
                  aria-label={`View ${item.title} in full screen`}
                >
                  {!failedImages[item.id] ? (
                    <img
                      src={item.src}
                      alt={item.title}
                      referrerPolicy="no-referrer"
                      onError={() => markFailed(item.id)}
                      className="h-full w-full object-cover transition-transform duration-500 ease-out group-hover:scale-[1.03]"
                    />
                  ) : (
                    <div className="flex h-full w-full flex-col items-center justify-center bg-[#FAF6EE] p-6 text-center text-[#8C6318]">
                      <p className="font-serif text-xl">{item.title}</p>
                      <p className="mt-2 text-xs opacity-75">{item.caption}</p>
                    </div>
                  )}

                  {/* Measured Warm Contrast Scrim */}
                  <div className="absolute inset-0 bg-gradient-to-t from-[#2B2113]/80 via-[#2B2113]/15 to-transparent opacity-90 sm:opacity-85 group-hover:opacity-100 transition-opacity" />

                  <div className="absolute top-4 right-4 flex h-9 w-9 items-center justify-center rounded-md bg-[#2B2113]/65 text-[#F5E9CC] opacity-0 group-hover:opacity-100 transition-opacity">
                    <Maximize2 className="w-4 h-4" />
                  </div>

                  <figcaption className="absolute inset-x-0 bottom-0 p-5 sm:p-6 text-[#FFFFFF]">
                    <p className="font-serif text-xl sm:text-2xl font-medium">
                      {item.title}
                    </p>
                    <p className="mt-1 text-xs sm:text-sm text-[#F5E9CC]/90 line-clamp-2">
                      {item.caption}
                    </p>
                  </figcaption>
                </button>
              </figure>
            );
          })}
        </div>
      </div>

      {/* Fullscreen Lightbox Modal */}
      {activeItem && activeIndex !== null && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-[#2B2113]/92 p-4 sm:p-8"
          role="dialog"
          aria-modal="true"
          aria-label={activeItem.title}
        >
          <button
            type="button"
            onClick={() => setActiveIndex(null)}
            className="absolute top-4 right-4 sm:top-6 sm:right-6 inline-flex h-11 w-11 items-center justify-center rounded-md border border-[#DFBF77]/50 text-[#FFFFFF] hover:bg-[#DFBF77]/20 transition-colors cursor-pointer"
            aria-label="Close photo viewer"
          >
            <X className="w-5 h-5" />
          </button>

          {visibleItems.length > 1 && (
            <>
              <button
                type="button"
                onClick={() =>
                  setActiveIndex(
                    (activeIndex - 1 + visibleItems.length) % visibleItems.length,
                  )
                }
                className="absolute left-3 sm:left-6 inline-flex h-11 w-11 items-center justify-center rounded-md border border-[#DFBF77]/50 text-[#FFFFFF] hover:bg-[#DFBF77]/20 transition-colors cursor-pointer"
                aria-label="Previous photograph"
              >
                <ChevronLeft className="w-5 h-5" />
              </button>

              <button
                type="button"
                onClick={() => setActiveIndex((activeIndex + 1) % visibleItems.length)}
                className="absolute right-3 sm:right-6 inline-flex h-11 w-11 items-center justify-center rounded-md border border-[#DFBF77]/50 text-[#FFFFFF] hover:bg-[#DFBF77]/20 transition-colors cursor-pointer"
                aria-label="Next photograph"
              >
                <ChevronRight className="w-5 h-5" />
              </button>
            </>
          )}

          <div className="max-w-4xl w-full flex flex-col items-center text-center">
            <div className="max-h-[75vh] w-full overflow-hidden rounded-lg border border-[#DFBF77]/45 bg-[#1F170D]">
              <img
                src={activeItem.src}
                alt={activeItem.title}
                referrerPolicy="no-referrer"
                className="max-h-[75vh] w-full object-contain mx-auto"
              />
            </div>
            <h3 className="mt-5 font-serif text-2xl sm:text-3xl text-[#FFFFFF]">
              {activeItem.title}
            </h3>
            <p className="mt-1.5 text-sm text-[#F5E9CC]/85 max-w-xl">
              {activeItem.caption}
            </p>
          </div>
        </div>
      )}
    </section>
  );
}
