import React, { useEffect, useState } from 'react';
import { Check, Copy, MessageCircle, X } from 'lucide-react';
import { WEDDING_DETAILS, buildWhatsAppShareUrl } from '../data/weddingData';

interface ShareModalProps {
  open: boolean;
  onClose: () => void;
}

export function ShareModal({ open, onClose }: ShareModalProps) {
  const [copiedLink, setCopiedLink] = useState(false);

  const shareUrl = typeof window !== 'undefined' ? window.location.origin : '';
  const whatsappUrl = buildWhatsAppShareUrl(shareUrl);

  useEffect(() => {
    if (!open) return;
    const handleEsc = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleEsc);
    return () => window.removeEventListener('keydown', handleEsc);
  }, [open, onClose]);

  if (!open) return null;

  const handleCopyLink = async () => {
    try {
      await navigator.clipboard.writeText(shareUrl);
      setCopiedLink(true);
      window.setTimeout(() => setCopiedLink(false), 2500);
    } catch {
      setCopiedLink(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-[#2B2113]/60 backdrop-blur-sm p-4"
      role="dialog"
      aria-modal="true"
      aria-label="Share Nikah Invitation"
      onClick={onClose}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="relative w-full max-w-md rounded-lg border border-[#C59B43]/65 bg-[#FFFFFF] p-6 sm:p-8 shadow-2xl"
      >
        <button
          type="button"
          onClick={onClose}
          className="absolute top-4 right-4 inline-flex h-10 w-10 items-center justify-center rounded-md text-[#6B5B45] hover:bg-[#FAF6EE] hover:text-[#8C6318] transition-colors cursor-pointer"
          aria-label="Close share dialog"
        >
          <X className="w-5 h-5" />
        </button>

        <p className="text-xs tracking-[0.22em] uppercase text-[#8C6318] font-medium">
          Share With Family &amp; Friends
        </p>
        <h3 className="mt-1.5 font-serif text-3xl font-medium text-[#2B2113]">
          Send Invitation
        </h3>
        <p className="mt-2 text-sm text-[#6B5B45] leading-relaxed">
          Share the digital Nikah invitation for {WEDDING_DETAILS.bride} &amp;{' '}
          {WEDDING_DETAILS.groom} directly on WhatsApp or copy the invitation link.
        </p>

        <div className="mt-6 space-y-3">
          <a
            href={whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-center gap-2.5 min-h-[46px] w-full px-6 py-3 rounded-md bg-[#9A6F20] text-[#FFFFFF] text-sm font-medium hover:bg-[#8C6318] transition-colors"
          >
            <MessageCircle className="w-4 h-4 text-[#F5E9CC]" />
            <span>Share via WhatsApp</span>
          </a>

          <button
            type="button"
            onClick={handleCopyLink}
            className="flex items-center justify-center gap-2.5 min-h-[46px] w-full px-6 py-3 rounded-md border border-[#C59B43]/75 text-[#8C6318] text-sm font-medium hover:bg-[#FAF6EE] transition-colors cursor-pointer"
          >
            {copiedLink ? (
              <>
                <Check className="w-4 h-4 text-[#8C6318]" />
                <span>Invitation Link Copied</span>
              </>
            ) : (
              <>
                <Copy className="w-4 h-4 text-[#B38734]" />
                <span>Copy Invitation Link</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
}
