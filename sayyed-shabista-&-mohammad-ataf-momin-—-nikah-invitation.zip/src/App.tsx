import React, { useState } from 'react';
import { EnvelopeOpening } from './components/EnvelopeOpening';
import { Navbar } from './components/Navbar';
import { HeroInvitation } from './components/HeroInvitation';
import { CountdownSection } from './components/CountdownSection';
import { ScheduleAndVenue } from './components/ScheduleAndVenue';
import { PhotoGallery } from './components/PhotoGallery';
import { RsvpSection } from './components/RsvpSection';
import { Footer } from './components/Footer';
import { ShareModal } from './components/ShareModal';
import {
  FloatingNasheedPlayer,
  useYouTubeNasheed,
} from './components/FloatingNasheedPlayer';

const ENVELOPE_SESSION_KEY = 'nikah_envelope_opened';

export default function App() {
  const [envelopeOpened, setEnvelopeOpened] = useState<boolean>(() => {
    if (typeof window === 'undefined') return false;
    const hasSectionHash = Boolean(window.location.hash && window.location.hash !== '#');
    return hasSectionHash && window.sessionStorage.getItem(ENVELOPE_SESSION_KEY) === 'true';
  });
  const [shareModalOpen, setShareModalOpen] = useState(false);

  const {
    containerRef,
    hasActivated,
    isPlaying,
    isMuted,
    hasError,
    startFromBeginning,
    togglePlay,
    toggleMute,
  } = useYouTubeNasheed();

  const handleCompleteOpening = () => {
    if (typeof window !== 'undefined') {
      window.sessionStorage.setItem(ENVELOPE_SESSION_KEY, 'true');
    }
    setEnvelopeOpened(true);
    window.scrollTo({ top: 0, behavior: 'auto' });
  };

  const handleReplayEnvelope = () => {
    if (typeof window !== 'undefined') {
      window.sessionStorage.removeItem(ENVELOPE_SESSION_KEY);
      if (window.location.hash) {
        window.history.replaceState(null, '', window.location.pathname);
      }
    }
    setEnvelopeOpened(false);
    window.scrollTo({ top: 0, behavior: 'auto' });
  };

  return (
    <div className="min-h-screen bg-[#FFFFFF] text-[#2B2113]">
      {/* Persistent off-visual YouTube player container so Nasheed never restarts across navigation */}
      <div
        aria-hidden="true"
        className="pointer-events-none fixed bottom-0 right-0 -z-10 h-28 w-44 overflow-hidden opacity-[0.001]"
      >
        <div ref={containerRef} />
      </div>

      {!envelopeOpened ? (
        <EnvelopeOpening
          onOpenStart={startFromBeginning}
          onComplete={handleCompleteOpening}
        />
      ) : (
        <>
          <Navbar onOpenShare={() => setShareModalOpen(true)} />
          <main>
            <HeroInvitation />
            <CountdownSection />
            <ScheduleAndVenue />
            <PhotoGallery />
            <RsvpSection />
          </main>
          <Footer onReplayEnvelope={handleReplayEnvelope} />
          <ShareModal open={shareModalOpen} onClose={() => setShareModalOpen(false)} />
        </>
      )}

      <FloatingNasheedPlayer
        visible={envelopeOpened || hasActivated}
        isPlaying={isPlaying}
        isMuted={isMuted}
        hasError={hasError}
        onTogglePlay={togglePlay}
        onToggleMute={toggleMute}
      />
    </div>
  );
}
