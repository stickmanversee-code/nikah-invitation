import express from 'express';
import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = Number(process.env.PORT) || 3000;
const IS_PROD = process.env.NODE_ENV === 'production';
const DATA_DIR = path.resolve(__dirname, 'data');
const RSVP_FILE = path.join(DATA_DIR, 'rsvps.json');

interface RsvpRecord {
  id: string;
  confirmationCode: string;
  guestName: string;
  phone: string;
  normalizedPhone: string;
  attending: 'yes' | 'no';
  guestCount: number;
  ceremonyPreference: 'both' | 'nikah' | 'dinner';
  duaMessage: string;
  shareDuaPublicly: boolean;
  createdAt: string;
  updatedAt: string;
}

let writeLock: Promise<void> = Promise.resolve();

function normalizePhone(input: string): string {
  const digits = input.replace(/\D/g, '');
  return digits.slice(-10);
}

function generateConfirmationCode(normalizedPhone: string): string {
  const suffix = crypto
    .createHash('sha256')
    .update(`${normalizedPhone}-${Date.now()}`)
    .digest('hex')
    .slice(0, 4)
    .toUpperCase();
  return `NIKAH-2312-${suffix}`;
}

async function ensureDataFile(): Promise<void> {
  await fs.mkdir(DATA_DIR, { recursive: true });
  try {
    await fs.access(RSVP_FILE);
  } catch {
    await fs.writeFile(RSVP_FILE, JSON.stringify([], null, 2), 'utf-8');
  }
}

async function readRsvps(): Promise<RsvpRecord[]> {
  await ensureDataFile();
  try {
    const raw = await fs.readFile(RSVP_FILE, 'utf-8');
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? (parsed as RsvpRecord[]) : [];
  } catch {
    return [];
  }
}

async function writeRsvps(records: RsvpRecord[]): Promise<void> {
  await ensureDataFile();
  const tempPath = `${RSVP_FILE}.tmp`;
  await fs.writeFile(tempPath, JSON.stringify(records, null, 2), 'utf-8');
  await fs.rename(tempPath, RSVP_FILE);
}

function withWriteLock<T>(task: () => Promise<T>): Promise<T> {
  const next = writeLock.then(task, task);
  writeLock = next.then(
    () => undefined,
    () => undefined,
  );
  return next;
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '64kb' }));

  app.get('/api/health', (_req, res) => {
    res.json({ status: 'ok' });
  });

  app.get('/api/rsvp/summary', async (_req, res) => {
    try {
      const records = await readRsvps();
      const attendingRecords = records.filter((r) => r.attending === 'yes');
      const totalAttendingGuests = attendingRecords.reduce((sum, r) => sum + r.guestCount, 0);
      const publicBlessings = records
        .filter((r) => r.shareDuaPublicly && r.duaMessage.trim().length > 0)
        .sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime())
        .slice(0, 12)
        .map((r) => ({
          id: r.id,
          guestName: r.guestName,
          duaMessage: r.duaMessage,
          attending: r.attending,
          updatedAt: r.updatedAt,
        }));

      res.json({
        totalResponses: records.length,
        confirmedFamilies: attendingRecords.length,
        totalAttendingGuests,
        publicBlessings,
      });
    } catch {
      res.status(500).json({ error: 'Unable to load RSVP summary.' });
    }
  });

  app.get('/api/rsvp/lookup', async (req, res) => {
    const rawPhone = typeof req.query.phone === 'string' ? req.query.phone : '';
    const normalized = normalizePhone(rawPhone);
    if (normalized.length < 7) {
      res.status(400).json({ error: 'Please enter a valid phone number with at least 7 digits.' });
      return;
    }

    try {
      const records = await readRsvps();
      const match = records.find((r) => r.normalizedPhone === normalized);
      if (!match) {
        res.status(404).json({ error: 'No RSVP found for this phone number.' });
        return;
      }

      res.json({
        confirmationCode: match.confirmationCode,
        guestName: match.guestName,
        attending: match.attending,
        guestCount: match.guestCount,
        ceremonyPreference: match.ceremonyPreference,
        duaMessage: match.duaMessage,
        shareDuaPublicly: match.shareDuaPublicly,
        updatedAt: match.updatedAt,
      });
    } catch {
      res.status(500).json({ error: 'Unable to verify RSVP right now.' });
    }
  });

  app.post('/api/rsvp', async (req, res) => {
    const body = req.body as Record<string, unknown> | undefined;
    if (!body || typeof body !== 'object') {
      res.status(400).json({ error: 'Invalid request payload.' });
      return;
    }

    const guestName = typeof body.guestName === 'string' ? body.guestName.trim() : '';
    const phone = typeof body.phone === 'string' ? body.phone.trim() : '';
    const attending = body.attending === 'yes' || body.attending === 'no' ? body.attending : null;
    const rawCount = typeof body.guestCount === 'number' ? body.guestCount : Number(body.guestCount);
    const ceremonyPreference =
      body.ceremonyPreference === 'both' ||
      body.ceremonyPreference === 'nikah' ||
      body.ceremonyPreference === 'dinner'
        ? body.ceremonyPreference
        : 'both';
    const duaMessage = typeof body.duaMessage === 'string' ? body.duaMessage.trim().slice(0, 400) : '';
    const shareDuaPublicly = Boolean(body.shareDuaPublicly);

    if (guestName.length < 2 || guestName.length > 80) {
      res.status(400).json({ error: 'Please enter your full name (2 to 80 characters).' });
      return;
    }

    const normalized = normalizePhone(phone);
    if (normalized.length < 7 || normalized.length > 15) {
      res.status(400).json({ error: 'Please enter a valid contact or WhatsApp number.' });
      return;
    }

    if (!attending) {
      res.status(400).json({ error: 'Please select whether you will be attending.' });
      return;
    }

    const guestCount = attending === 'yes' ? Math.min(10, Math.max(1, Math.round(rawCount || 1))) : 0;

    try {
      const saved = await withWriteLock(async () => {
        const records = await readRsvps();
        const now = new Date().toISOString();
        const existingIndex = records.findIndex((r) => r.normalizedPhone === normalized);

        if (existingIndex >= 0) {
          const existing = records[existingIndex];
          const updated: RsvpRecord = {
            ...existing,
            guestName,
            phone,
            attending,
            guestCount,
            ceremonyPreference,
            duaMessage,
            shareDuaPublicly,
            updatedAt: now,
          };
          records[existingIndex] = updated;
          await writeRsvps(records);
          return { record: updated, isUpdate: true };
        }

        const created: RsvpRecord = {
          id: crypto.randomUUID(),
          confirmationCode: generateConfirmationCode(normalized),
          guestName,
          phone,
          normalizedPhone: normalized,
          attending,
          guestCount,
          ceremonyPreference,
          duaMessage,
          shareDuaPublicly,
          createdAt: now,
          updatedAt: now,
        };
        records.push(created);
        await writeRsvps(records);
        return { record: created, isUpdate: false };
      });

      res.status(saved.isUpdate ? 200 : 201).json({
        isUpdate: saved.isUpdate,
        confirmation: {
          confirmationCode: saved.record.confirmationCode,
          guestName: saved.record.guestName,
          attending: saved.record.attending,
          guestCount: saved.record.guestCount,
          ceremonyPreference: saved.record.ceremonyPreference,
          duaMessage: saved.record.duaMessage,
          shareDuaPublicly: saved.record.shareDuaPublicly,
          updatedAt: saved.record.updatedAt,
        },
      });
    } catch {
      res.status(500).json({ error: 'Unable to save your RSVP right now. Please try again.' });
    }
  });

  if (!IS_PROD) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(__dirname, 'dist');
    app.use(express.static(distDir));
    app.get('*path', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Nikah invitation server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
